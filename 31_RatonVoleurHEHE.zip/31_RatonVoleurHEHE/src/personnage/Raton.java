package personnage;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.Point2D;

import ameliorations.BoostHorizontal;
import ameliorations.BoostVertical;
import ameliorations.Champ;
import geometrieDessin.Vecteur2D;
import obstacles.Batiment;
import obstacles.Roche;
import obstacles.Sapin;
import obstacles.Voiture;
import outils.Dessinable;
import physique.MoteurPhysique;
import ameliorations.Champ;

/**
 * Le personnage principal du jeu
 * @author Justin Gauthier
 */
public class Raton implements Dessinable {
	/**Le cercle qui delimite le raton**/
	private Ellipse2D.Double dimensionRaton;
	/**Le vecteur de la position du raton**/
	private Vecteur2D position;
	/**La largeur du raton**/
	private double largeur;
	/**La hauteur du raton**/
	private double hauteur;
	/**La masse du raton**/
	private double masse = 1;
	/**Determine si il y a une collision ou non**/
	private boolean collision;
	/**La coordonnée en x du coin superieur gauche du raton**/
	private double x;
	/**La coordonnée en y du coin superieur gauche du raton**/
	private double y;
	/**permet de gerer le champ electrique**/
	private double vx;
	/**permet de gerer le champ electrique**/
	private double vy;
	/**L'etat d'activaton de l'attraction du raton**/
	private boolean attractionActif = false;
	/**Le champ memorise par le raton**/
	private Champ champAttire;
	/** vecteur de vitesse du bloc **/
	private Vecteur2D vitesse = new Vecteur2D(0,0);
	/** vecteur d'acceleration du bloc **/
	private Vecteur2D accel = new Vecteur2D(0,0);
	/** vecteur de somme des forces appliquees sur le bloc **/
	private Vecteur2D fTotale= new Vecteur2D();
	/** vecteur de force gravitationnel appliquee sur le bloc **/
	private Vecteur2D  fGravit = new Vecteur2D();
	/**vecteur de force du lancement du raton()**/
	private Vecteur2D fLancement;
	/**Le cercle qui delimite le raton**/
	private Ellipse2D.Double raton;
	/**Le nombre de pixels par metre**/
	private double pixelsParMetre =1;
	/**La charge du raton**/
	private double charge = -1;
	Shape s = (Shape) raton;
	/**
	 * Le constructeur du raton
	 * @param position le vecteur de la position du raton
	 * @param rayon le rayon du cercle qui delimite le raton
	 */
	//Justin Gauthier
	public Raton(Vecteur2D position, double rayon) {
		this.position = new Vecteur2D(position);
		this.largeur = rayon * 2;
		this.hauteur = rayon * 2;
		creerLaGeometrie();
	}

	/**Permet de tester la collision du batiment
	 * 
	 * @param  active  ça nous dis si l'attraction est actif ou non
	 * @param champ qui nous donne le champ
	 */ 
	//Edson François Gertilus
	public void setAttractionActif(boolean active, Champ champ) {
		this.attractionActif = active;
		this.champAttire = champ;
	}

	/**Permet de savoir si l'atttraction est actif
	 * 
	 * @return la réponse si le champ est actif ou non
	 * 
	 */ 
	//Edson François Gertilus
	public boolean estAttractionActif() {
		return attractionActif;
	}

	/**Cette méthode donne les attributs du champ
	 * 
	 * @return le champ attiré
	 */ 
	//Edson François Gertilus
	public Champ getChampAttire() {
		return champAttire;
	}

	/**Permet d'ajouter une force utile pour l'attraction
	 * 
	 * @param fx la force en x
	 * @param fy la force en y
	 */ 
	//Edson François Gertilus
	public void ajouterForce(double fx, double fy) {
		vx += fx / masse;
		vy += fy / masse;
	}

	/**Permet d'ajouter une force utile pour l'attraction
	 * 
	 * @param deltaT la variation du temps
	 */ 
	//Edson François Gertilus
	public void PositionTempsReel(double deltaT) {
		x += vx * deltaT;
		y += vy * deltaT;
	}

	/**Permet d'avoir la position x
	 * 
	 * @return x la position x
	 */ 
	//Edson François Gertilus
	public void updatePosition(double deltaT) {
		x += vx * deltaT;
		y += vy * deltaT;
	}

	/**
	 * permet d'obtenir la position en x du raton
	 * @return la position en x du raton
	 */
	//Justin Gauthier
	public double getX() {
		return x; 
	}

	/**
	 * permet d'obtenir la position en y du raton
	 * @return la position en y du raton
	 */
	//Justin Gauthier
	public double getY() {
		return y; 
	}

	/**Permet d'avoir la position x
	 * 
	 * @param force la force qui qu'on va appliquer dépendamment de la direction
	 */ 
	//Edson François Gertilus
	public void appliquerForceDirection(Vecteur2D force) {
		this.vitesse = this.vitesse.additionne(force);
	}

	/**Permet d'avoir les dimensions du raton
	 * 
	 * @return la forme du raton
	 */ 
	//Edson François Gertilus
	public Ellipse2D.Double getForme() {
		return new Ellipse2D.Double(position.getX(), position.getY(), largeur, hauteur);
	}

	/**Permet d'avoir les dimensions du raton
	 * 
	 * @param direction c'est la direction dans dans laquel la force sera appliquée
	 */ 
	//Edson François Gertilus
	public void appliquerAttraction(Vecteur2D direction) {
		double force = 0.15; // Ajustez cette valeur pour l'intensité
		this.vitesse = this.vitesse.additionne(direction.multiplie(force));
	}

	/**
	 * Permet de creer la geometrie du cercle qui delimite le raton
	 */
	//Justin Gauthier
	private void creerLaGeometrie() {
		raton = (new Ellipse2D.Double(position.getX(), position.getY(), largeur, hauteur));
	}

	/**
	 * Permet de dessiner le cercle qui delimite le raton
	 */
	//Justin Gauthier
	@Override
	public void dessiner(Graphics2D g2d) {
		Graphics2D g2dPrive = (Graphics2D) g2d.create();
		g2dPrive.scale(pixelsParMetre, pixelsParMetre);
		g2dPrive.fill(raton);
	}

	/**
	 * Permet d'obtenir le rayon du cercle qui delimite le raton
	 * @return le rayon du cercle qui delimite le raton
	 */
	//Justin Gauthier
	public double getRayon() {
		return largeur/2;

	}

	/**
	 * Permet de changer la coordonnée en y du raton
	 * @param y la nouvelle coordonnée en y 
	 */
	//Justin Gauthier
	public void setY(double y) {
		position.setY(y);
		creerLaGeometrie();
	}

	/**
	 * Permet de changer l'acceleration du raton
	 * @param accel la nouvelle acceleration du raton
	 */
	//Justin Gauthier
	public void setAccel(Vecteur2D accel) {
		this.accel = accel;
	}

	/**
	 * Permet d'obtenir l'acceleration du raton
	 * @return l'acceleration du raton
	 */
	//Justin Gauthier
	public Vecteur2D getAccel() {
		return accel;
	}

	/**
	 * permet de changer le vecteur de la position du raton
	 * @param position la nouvelle position du raton
	 */
	//Justin Gauthier
	public void setPosition(Vecteur2D position) {
		this.position = position;
	}

	/**
	 * Permet d'obtenir la position du raton
	 * @return la position du raton
	 */
	//Justin Gauthier
	public Vecteur2D getPosition() {
		return position;
	}

	/**
	 * Permet de changer le vitesse du raton
	 * @param vitesse la nouvelle vitesse du raton
	 */
	//Justin Gauthier
	public void setVitesse(Vecteur2D vitesse) {
		this.vitesse = vitesse;
	}

	/**
	 * Permet d'obtenir la vitesse du raton
	 * @return la vitesse du raton
	 */
	//Justin Gauthier
	public Vecteur2D getVitesse() {
		return vitesse;
	}

	/**
	 * Permet de changer la masse du raton
	 * @param massse la nouvelle masse du raton
	 */
	//Justin Gauthier
	public void setMasse(double massse) {
		this.masse = masse;
	}

	/**
	 * Permet d'obtenir la masse du raton
	 * @return la masse du raton
	 */
	//Justin Gauthier
	public double getMasse() {
		return masse;
	}

	public double getCharge() {
		return charge;
	}

	public void ajouterForce(Vecteur2D force) {
		fTotale = fTotale.additionne(force);
	}

	/**
	 * Permet de changer la somme des forces qui sont appliquées sur le raton
	 * @param sommeForces la somme des forces qui sont appliquées sur le raton
	 */
	//Justin Gauthier
	public void setSommeDesForces(Vecteur2D sommeForces) {
		fTotale = sommeForces;
		try {
			accel = MoteurPhysique.calculAcceleration(fTotale, masse);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Permet de calculer une iteration physique du mouvement du raton en se basant sur un pas de simulation donné
	 * @param pasSimulation le pas de simulation de la simulation physique
	 */
	//Justin Gauthier
	public void calculerIteration(double pasSimulation) {
		double positionX = position.getX();
		vitesse = MoteurPhysique.calculVitesse(pasSimulation, vitesse, accel);
		position = MoteurPhysique.calculPosition(pasSimulation, position, vitesse);
		position.setX(positionX);
		creerLaGeometrie();
	}

	public Ellipse2D.Double getRaton() {

		return dimensionRaton;
	}
	/**Permet d'avoir  des collisions quand le batiment touche le raton 
	 * 
	 * 
	 * @param batiment c'est l'obstacle du batiment
	 *
	 */ 
	//Edson François Gertilus
	public void gererCollisionBatiment(Batiment batiment) {
		if (batiment.checkCollisionBatiment(raton)) {

			double ratonCentreX = position.getX() + largeur/2;
			double ratonCentreY = position.getY() + hauteur/2;

			double batimentGauche=batiment.getX();
			double batimentDroite=batiment.getX() + batiment.getLongueurBatiment();

			double batimentHaut=batiment.getY();
			double batimentBas = batiment.getY() + batiment.getHauteurBatiment();

			//J'utilise Math Absolue parce ça me permet d'avoir une valeur même si c'est négatif

			double distGauche=Math.abs( ratonCentreX-batimentGauche);

			double distDroite=Math.abs( ratonCentreX-batimentDroite);

			double distHaut=Math.abs( ratonCentreY-batimentHaut);

			double distBas=Math.abs( ratonCentreX-batimentGauche);


			Vecteur2D normal;
			if (distGauche <= distDroite && distGauche <= distHaut && distGauche <= distBas) {
				// Alors la collision est  a gauche 
				normal = new Vecteur2D(-1, 0);
				position.setX( batimentGauche- largeur);
			}else if (distDroite <= distGauche && distDroite <= distHaut && distDroite <= distBas) {
				// Alors la collision est  a droite
				normal = new Vecteur2D(1, 0);
				position.setX(batimentDroite);
			}else if(distHaut <= distGauche && distHaut<= distDroite &&  distHaut<= distBas) {
				// Alors la collision est en haut
				normal = new Vecteur2D(0, -1);
				position.setY(batimentHaut-hauteur);
			} else {
				// Alors la collision est en bas
				normal = new Vecteur2D(0, 1);
				position.setY(batimentBas);
			}
			double produitScalaire = vitesse.getX() * normal.getX() + vitesse.getY() * normal.getY();

			if (produitScalaire < 0) {
				Vecteur2D nouvelleVitesse = new Vecteur2D( vitesse.getX() - 2 * produitScalaire * normal.getX(),   vitesse.getY() - 2 * produitScalaire * normal.getY());

				this.setVitesse(nouvelleVitesse);
			}
			creerLaGeometrie();
		}
	}
	/**Permet d'avoir  des collisions quand la roche touche le raton 
	 * 
	 * 
	 * @param roche c'est l'obstacle de la roche
	 *
	 */ 
	//Edson François Gertilus
	public void gererCollisionRoche(Roche roche) {
		if (roche.checkCollisionRoche(raton)) {
			double ratonCentreX = position.getX() + largeur/2;
			double ratonCentreY = position.getY() + hauteur/2;

			double rocheGauche=roche.getX();
			double rocheDroite=roche.getX() + roche.getLongueurRoche();
			double rocheHaut=roche.getY();
			double rocheBas=roche.getY() + roche.getHauteurRoche();


			double distGauche=Math.abs( ratonCentreX-rocheGauche);
			double distDroite=Math.abs( ratonCentreX-rocheDroite);
			double distHaut=Math.abs(ratonCentreY-rocheHaut);
			double distBas=Math.abs(ratonCentreY-rocheBas);

			Vecteur2D normal;
			if (distGauche <= distDroite && distGauche <= distHaut && distGauche <= distBas) {
				// Collision à gauche
				normal = new Vecteur2D(-1, 0);
				position.setX(rocheGauche-largeur);
			}else if(distDroite <= distGauche && distDroite <= distHaut && distDroite <= distBas){
				// Collision à droite
				normal = new Vecteur2D(1, 0);
				position.setX(rocheDroite);
			} else if (distHaut <= distGauche && distHaut<= distDroite &&  distHaut<= distBas) {
				// Collision en haut
				normal = new Vecteur2D(0, -1);
				position.setY(rocheHaut-hauteur);
			} else {
				// Collision en bas
				normal = new Vecteur2D(0, 1);
				position.setY(rocheBas);
			}
			double produitScalaire = vitesse.getX() * normal.getX() + vitesse.getY() * normal.getY();


			if (produitScalaire < 0) {
				Vecteur2D nouvelleVitesse = new Vecteur2D(
						vitesse.getX() - 2 * produitScalaire * normal.getX(),
						vitesse.getY() - 2 * produitScalaire * normal.getY()
						);
				this.setVitesse(nouvelleVitesse);
			}
			creerLaGeometrie();
		}
	}
	/**Permet d'avoir  des collisions quand la roche touche le raton 
	 * 
	 * 
	 * @param sapin c'est l'obstacle de la roche
	 * @throws Exception 
	 *
	 */ 
	//Edson François Gertilus
	
	/**Permet d'avoir  des collisions quand la voiture touche le raton 
	 * 
	 * 
	 * @param voiture c'est l'obstacle de la voiture
	 *
	 */ 
	//Edson François Gertilus
	// Nouvelle méthode dans la classe Sapin


	public void gererCollisionSapin(Sapin sapin) {
	    if (sapin.checkCollisionSapin(raton)) {
	        double ratonCentreX = position.getX() + largeur/2;
	        double ratonCentreY = position.getY() + hauteur/2;

	        // Coordonnées du sapin
	        double sapinGauche = sapin.getX();
	        double sapinDroite = sapin.getX() + sapin.getLongueurSapin();
	        double sapinApexX = sapinGauche + sapin.getLongueurSapin()/2;
	        double sapinApexY = sapin.getY();

	        // Seuils de détection
	        final double SEUIL_APEX_X = 0.2; // Tolérance horizontale apex
	        final double SEUIL_APEX_Y = 0.3; // Tolérance verticale apex

	        // 1. Vérifier collision avec apex
	        boolean collisionApex = 
	            (Math.abs(ratonCentreX - sapinApexX) < SEUIL_APEX_X) && 
	            (Math.abs(ratonCentreY - sapinApexY) < SEUIL_APEX_Y);

	        if(collisionApex) {
	            // Rebond vertical
	            vitesse.setY(-Math.abs(vitesse.getY()));
	            position.setY(sapinApexY - hauteur - 0.05);
	        }
	        else {
	            // 2. Déterminer côté de collision
	            if(ratonCentreX > sapinApexX) { 
	                // Collision côté droit - rebond à droite
	                position.setX(sapinDroite + 0.05);
	                vitesse.setX(Math.abs(vitesse.getX()));
	            }
	            else { 
	                // Collision côté gauche - rebond à gauche
	                position.setX(sapinGauche - largeur - 0.05);
	                vitesse.setX(-Math.abs(vitesse.getX()));
	            }
	        }

	        creerLaGeometrie();
	    }
	}
	
	/**Permet d'avoir  une améliration quand le raton touche le boostHorizontal 
	 * 
	 * 
	 * @param BoostHorizontal c'est le boost horizontal
	 *
	 */ 
	//Edson François Gertilus
	public void gererCollisionBoostHorizontal(BoostHorizontal BoostHorizontal) {
		if (BoostHorizontal.checkCollisionHorizontal(raton)) {
			appliquerBoostHorizontal(vitesse);

		}
		creerLaGeometrie();
	}
	/**Permet d'avoir  une améliration quand le raton touche le boostHorizontal 
	 * 
	 * 
	 * @param BoostVertical c'est le boost vertical
	 *
	 */ 
	//Edson François Gertilus

	public void gererCollisionBoostVertical(BoostVertical BoostVertical) {
		if (BoostVertical.checkCollisionVertical(raton)) {
			appliquerBoostVertical(vitesse);

		}
		creerLaGeometrie();
	}
	/**Permet d'appliquer le boostHorizontal
	 * 
	 * 
	 * @param vitesse c'est la vitesse du raton
	 *
	 */ 
	//Edson François Gertilus
	public static Vecteur2D appliquerBoostHorizontal(Vecteur2D vitesse) {
		double BOOST_HORIZONTAL = 3.0;
		vitesse.setX(vitesse.getX() + BOOST_HORIZONTAL);
		return vitesse;
	}
	/**Permet d'appliquer le boostVertical
	 * 
	 * 
	 * @param vitesse c'est la vitesse du raton
	 *
	 */ 
	
	public static Vecteur2D appliquerBoostVertical(Vecteur2D vitesse) {
		double BOOST_VERTICAL = 3.0;
		vitesse.setY(vitesse.getY() + BOOST_VERTICAL);
		return vitesse;
	}


	/**
	 * Permet de gérer la collision du raton avec le sol
	 * @param ySol la position en y du sol
	 */
	//Justin Gauthier
	public void gererCollisionSol(double ySol) {
		if(this.getPosition().getY()+this.largeur>=ySol) {
			Vecteur2D nouvelleVitesse = new Vecteur2D(this.vitesse.getX(), -1*(this.getVitesse().getY()));
			this.setVitesse(nouvelleVitesse);
			Vecteur2D position = new Vecteur2D(this.position.getX(),ySol-this.largeur-0.01);
			this.setPosition(position);
			creerLaGeometrie();
		}
	}

	/**
	 * Calcule l'incrément de déplacement en x pour les objets et le background
	 * @param pasSimulation le pas de simulation de l'animation
	 * @return l'increment de deplacement en x
	 */
	//Justin Gauthier
	public double getIncrementX(double deltaT) {
		return vitesse.getX()*deltaT;
	}

	/**
	 * Modifie le facteur permettant de passer des metres aux pixels lors du dessin
	 * Ainsi on peut exprimer tout en m,  m/s  et m/s2
	 * @param pixelsParMetre Facteur de mise à l'échelle lors du dessin
	 */
	//Justin Gauthier
	public void setPixelsParMetre(double pixelsParMetre) {
		this.pixelsParMetre = pixelsParMetre;

	}
	public void gererCollisionChamp(Champ champ) {
	    // On veut que le champ agisse même à distance, pas besoin d'une collision directe
	    // Calcul de la direction vers le champ
	    double dx = champ.getPosition().getX() + champ.RAYON - (this.getPosition().getX() + this.getRayon());
	    double dy = champ.getPosition().getY() + champ.RAYON - (this.getPosition().getY() + this.getRayon());
	    double distance = Math.sqrt(dx * dx + dy * dy);
	    
	    // Éviter les divisions par zéro
	    if (distance < 0.1) {
	        distance = 0.1;
	    }
	    
	    // Utiliser la méthode existante pour calculer la force électrique
	    Vecteur2D forceElectrique = MoteurPhysique.calculForceElectriquePhysique(
	        this.getPosition(), 
	        this.getCharge(), 
	        champ.getPosition(), 
	        champ.getCharge()
	    );
	    
	    // Appliquer la force
	    this.fTotale = this.fTotale.additionne(forceElectrique);
	    
	    // Mettre à jour l'accélération
	    try {
	        this.setAccel(MoteurPhysique.calculAcceleration(this.fTotale, this.getMasse()));
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
}
