package application;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import composantdessin.JeuPrincipal;
import geometrieDessin.Vecteur2D;
import physique.GestionnaireEvenementsPhysique;
import physique.MoteurPhysique;
import voletInstructionsEtPropos.FenetreAideInstructions;

import javax.swing.JProgressBar;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import composantdessin.JeuPrincipal;
import javax.swing.JSlider;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.event.ChangeEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

/**
 * Fenêtre du jeu dans lequel le joeur pourra jouer avec les différents boutons et fonctionalités.
 * @author Justin Gathier
 * @author Stanislav Kouznetsov 
 */
public class Jouer extends JFrame {

	private static final long serialVersionUID = 1L;

    /** Panneau principal contenant l'interface du jeu. */
    private JPanel contentPane;

    /** Instance du magasin permettant d'accéder à la boutique du jeu. */
    private Magasin magasin;

    /** Instance de l'application principale. */
    private Application31 application;

    /** Instance du sélecteur de niveaux. */
    private Selectionneur selectionneur;

    /** Instance de l'éditeur de niveaux. */
    private Editeur editeur;

    /** Instance principale du jeu. */
    private JeuPrincipal jeu;

    /** Bouton permettant de passer à l'image suivante. */
    private JButton btnProchaineImage;

    /** Bouton permettant de démarrer le jeu. */
    private JButton btnPlay;

    /** Curseur permettant d'ajuster l'orientation. */
    private JSlider sliderOrientation;

    /** Curseur permettant d'ajuster la force. */
    private JSlider sliderForce;

    /** Barre de progression du niveau en cours. */
    private JProgressBar barreDeProgresNiveau;

    /** Événement lié à un changement de propriété. */
    private PropertyChangeEvent evt;

    /** Label affichant le score actuel. */
    private JLabel lblScore;

    /** Case à cocher permettant d'afficher ou non le vecteur des forces. */
    private JCheckBox chckbxAfficherVecteur;
    
    /** Gère les événements physiques du jeu. */
    private GestionnaireEvenementsPhysique gestionnaire;

    /** Tableau affichant les paramètres physiques. */
    private JTable tablePhysique;

	/**
	 * Lance l'application
	 * @param args Arguments de la ligne de commande.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Jouer frame = new Jouer();
					frame.setVisible(true);
					frame.jeu.requestFocusInWindow();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Créer l'application.
	 */
	//Justin Gauthier
	public Jouer() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1300, 700);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnInstructions = new JMenu("Instructions");
		menuBar.add(mnInstructions);
		
		FenetreAideInstructions fenInstructions = new FenetreAideInstructions();
		JMenuItem mntmNewMenuItem = new JMenuItem("Instructions du jeu");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fenInstructions.setVisible(true);
				jeu.requestFocusInWindow();
			}
		});
		mnInstructions.add(mntmNewMenuItem);
		
		
		
		JMenu mnNaviguer = new JMenu("Naviguer");
		menuBar.add(mnNaviguer);
		
		JMenuItem mntmSelecteurNiveau = new JMenuItem("Selectionner un niveau");
		mntmSelecteurNiveau.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectionneur = new Selectionneur();
				selectionneur.setVisible(true);
				dispose();
			}
		});
		mnNaviguer.add(mntmSelecteurNiveau);
		
		JMenuItem mntmEditeurNiveau = new JMenuItem("Éditeur de niveau");
		mntmEditeurNiveau.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editeur = new Editeur();
				editeur.setVisible(true);
				dispose();
			}
		});
		mnNaviguer.add(mntmEditeurNiveau);
		
		JMenuItem mntmMenuPrincipal = new JMenuItem("Menu principal");
		mntmMenuPrincipal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				application = new Application31();
				application.setVisible(true);
				dispose();
			}
		});
		mnNaviguer.add(mntmMenuPrincipal);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		barreDeProgresNiveau = new JProgressBar();
        barreDeProgresNiveau.setForeground(Color.GREEN);
        barreDeProgresNiveau.setStringPainted(true);
        barreDeProgresNiveau.setBounds(10, 587, 944, 14);
        contentPane.add(barreDeProgresNiveau);

		
		
		JLabel lblMenuPhysique = new JLabel("Menu physique");
		lblMenuPhysique.setFont(new Font("Tahoma", Font.PLAIN, 39));
		lblMenuPhysique.setBounds(983, 0, 281, 92);
		contentPane.add(lblMenuPhysique);
		
		chckbxAfficherVecteur = new JCheckBox("Afficher le vecteur des forces");
		chckbxAfficherVecteur.setBounds(997, 334, 257, 23);
		contentPane.add(chckbxAfficherVecteur);
		

		btnPlay = new JButton("Play");
		btnPlay.setEnabled(false);
		btnPlay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (jeu.getPeutCliquer() || sliderOrientation.isVisible() || sliderForce.isVisible()) 
					btnPlay.setEnabled(false);
				else {
					jeu.demarrer();
					btnPlay.setEnabled(false);
					btnProchaineImage.setEnabled(false);
					}
				jeu.requestFocusInWindow();
				
			}
		});
		btnPlay.setBounds(997, 364, 125, 60);
		contentPane.add(btnPlay);
		
		JButton btnPause = new JButton("Pause");
		btnPause.setEnabled(false);
		btnPause.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				jeu.arreter();
				btnProchaineImage.setEnabled(true);
				btnPlay.setEnabled(true);
				jeu.requestFocusInWindow();
			}
		});
		btnPause.setBounds(997, 429, 125, 60);
		contentPane.add(btnPause);
		
		btnProchaineImage = new JButton("+1");
		btnProchaineImage.setEnabled(false);
		btnProchaineImage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (btnPlay.isEnabled()) {
					btnProchaineImage.setEnabled(true);
				}
				try {
					jeu.prochaineImage();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				jeu.requestFocusInWindow();
			}
		});
		btnProchaineImage.setBounds(1132, 364, 125, 125);
		contentPane.add(btnProchaineImage);
		
		JButton btnReplay = new JButton("Replay");
		btnReplay.setEnabled(false);
		btnReplay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					jeu.reinitialiser();
					btnProchaineImage.setEnabled(false);
					btnPlay.setEnabled(false);
					btnPause.setEnabled(false);
					btnReplay.setEnabled(false);
					chckbxAfficherVecteur.setSelected(false);
					
					tablePhysique.setModel(new DefaultTableModel(
				            new Object[][] {
				                {"Accélération", null, null}, 
				                {"Vitesse", null, null}, 
				                {"Force Grav.", null, null}, 
				                {"Position", null, null}
				            },
				            new String[] { "Paramètres", "X", "Y" }
				        ));
					
					
				// écrire le code pour ca en haut de jeu.requestFocusInWindow();
					jeu.requestFocusInWindow();
			}
		});
		btnReplay.setBounds(997, 500, 125, 125);
		contentPane.add(btnReplay);
		
		JButton btnMagasin = new JButton("Magasin");
		btnMagasin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				magasin = new Magasin();
				magasin.setVisible(true);
				dispose();
			}
		});
		btnMagasin.setBounds(1132, 500, 125, 125);
		contentPane.add(btnMagasin);
		
		jeu = new JeuPrincipal();
		
		jeu.addPropertyChangeListener(new PropertyChangeListener() {
		    public void propertyChange(PropertyChangeEvent evt) {
		        mettreAJourTableau(evt);
		    }
		});
		
		
		jeu.setBounds(10, 11, 944, 536);
		contentPane.add(jeu);
		jeu.setLayout(null);
		
		
		 jeu.addPropertyChangeListener("progression", new PropertyChangeListener() {
	            public void propertyChange(PropertyChangeEvent evt) {
	                modifierBarreJeu(evt);
	            }
	        });
	    
		sliderOrientation = new JSlider();
		sliderOrientation.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				jeu.repaint();
				jeu.requestFocusInWindow();
			}
		});
		sliderOrientation.setValue(45);
		sliderOrientation.setEnabled(false);
		sliderOrientation.setVisible(false);
		sliderOrientation.setPaintLabels(true);
		sliderOrientation.setMinimum(5);
		sliderOrientation.setMaximum(90);
		sliderOrientation.setPaintTicks(true);
		sliderOrientation.setMajorTickSpacing(5);
		sliderOrientation.setMinorTickSpacing(1);
		sliderOrientation.setOrientation(SwingConstants.VERTICAL);
		sliderOrientation.setBounds(224, 11, 77, 496);
		jeu.add(sliderOrientation);
		jeu.setOrientationAssocie(sliderOrientation);
		
		JButton btnSuivant = new JButton("Suivant");
		btnSuivant.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				jeu.sOrientationDisparait();
				jeu.suivantDisparait();
				jeu.rendreSForceVisible();
				jeu.setOrientation((double)sliderOrientation.getValue());
				repaint();
				jeu.requestFocusInWindow();
				
				
			}
		});
		btnSuivant.setEnabled(false);
		btnSuivant.setVisible(false);
		btnSuivant.setBounds(308, 262, 89, 23);
		jeu.add(btnSuivant);
		jeu.setSuivantAssocie(btnSuivant);
		
		sliderForce = new JSlider();
		sliderForce.setPaintLabels(true);
		sliderForce.setValue(200);
		sliderForce.setMinimum(50);
		sliderForce.setMaximum(200);
		sliderForce.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				jeu.repaint();
				jeu.requestFocusInWindow();
			}
		});
		sliderForce.setEnabled(false);
		sliderForce.setVisible(false);
		sliderForce.setMajorTickSpacing(50);
		sliderForce.setMinorTickSpacing(10);
		sliderForce.setOrientation(SwingConstants.VERTICAL);
		sliderForce.setPaintTicks(true);
		sliderForce.setBounds(224, 11, 77, 496);
		jeu.add(sliderForce);
		jeu.setForceAssocie(sliderForce);
		
		lblScore = new JLabel("Score : 0");
		jeu.addPropertyChangeListener("score", new PropertyChangeListener() {
		    @Override
		    public void propertyChange(PropertyChangeEvent evt) {
		    	modifierScore(evt);
		    	jeu.requestFocusInWindow();
		    }
		});
		
		lblScore.setBounds(791, 27, 103, 23);
		jeu.add(lblScore);
		
		JButton btnTermine = new JButton("Terminé");
		btnTermine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					jeu.sForceDisparait();
					btnPause.setEnabled(true);
					btnTermine.setVisible(false);
					btnReplay.setEnabled(true);
					jeu.setForce((double)sliderForce.getValue());
					jeu.demarrer();
					repaint();
					jeu.requestFocusInWindow();
			}
		});
		btnTermine.setEnabled(false);
		btnTermine.setVisible(false);
		btnTermine.setBounds(308, 262, 89, 23);
		jeu.add(btnTermine);
		jeu.setTermineAssocie(btnTermine);
		
		
		
		
		gestionnaire = new GestionnaireEvenementsPhysique(new MoteurPhysique());
		jeu.addPropertyChangeListener(new PropertyChangeListener() {
		    public void propertyChange(PropertyChangeEvent evt) {
		        mettreAJourTableau(evt);
		    }
		});
		
		tablePhysique = new JTable();
		tablePhysique.setFont(new Font("Tahoma", Font.PLAIN, 20));
		tablePhysique.setForeground(Color.BLACK);
		tablePhysique.setBackground(Color.WHITE);
		tablePhysique.setRowHeight(30);

		tablePhysique.setModel(new DefaultTableModel(
		    new Object[][] {
		        {"Accélération", null, null}, 
		        {"Vitesse", null, null}, 
		        {"Force Grav.", null, null}, 
		        {"Position", null, null}
		    },
		    new String[] { "Paramètres", "X", "Y" }
		));

		tablePhysique.setBounds(964, 109, 336, 125);
		contentPane.add(tablePhysique);
		
		JLabel lblForceEnX = new JLabel("X");
		lblForceEnX.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForceEnX.setBounds(1114, 79, 20, 20);
		contentPane.add(lblForceEnX);
		
		JLabel lblForceEnY = new JLabel("Y");
		lblForceEnY.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblForceEnY.setBounds(1234, 76, 20, 23);
		contentPane.add(lblForceEnY);
	}
		
	/**
	 * Met à jour le tableau des données physiques en fonction de l'événement reçu.
	 * 
	 * @param evt Événement contenant la propriété mise à jour et sa nouvelle valeur.
	 */
	//Stanislav Kouznetsov
	private void mettreAJourTableau(PropertyChangeEvent evt) {
	    if (evt.getNewValue() instanceof Vecteur2D) {
	        Vecteur2D valeur = (Vecteur2D) evt.getNewValue();
	        switch (evt.getPropertyName()) {
	            case "acceleration":
	                tablePhysique.setValueAt(String.format("%.3f", valeur.getX()), 0, 1);
	                tablePhysique.setValueAt(String.format("%.3f", valeur.getY()), 0, 2);
	                break;
	            case "vitesse":
	                tablePhysique.setValueAt(String.format("%.3f", valeur.getX()), 1, 1);
	                tablePhysique.setValueAt(String.format("%.3f", valeur.getY()), 1, 2);
	                break;
	            case "forceGrav":
	                tablePhysique.setValueAt(String.format("%.3f", valeur.getX()), 2, 1);
	                tablePhysique.setValueAt(String.format("%.3f", valeur.getY()), 2, 2);
	                break;
	            case "position":
	                tablePhysique.setValueAt(String.format("%.3f", valeur.getX()), 3, 1);
	                tablePhysique.setValueAt(String.format("%.3f", valeur.getY()), 3, 2);
	                break;
	        }
	    }
	}
	
	
	/**
     * Met à jour la barre de progression du niveau.
     * 
     * @param evt Événement contenant la nouvelle valeur de progression.
     * 
     */
	//Stanislav Kouznetsov
    public void modifierBarreJeu(PropertyChangeEvent evt) {
        int valeur = (int) evt.getNewValue();
        barreDeProgresNiveau.setValue(valeur);
    }
	
	
    /**
     * Met à jour l'affichage du score.
     * 
     * @param evt Événement contenant le nouveau score.
     */
    //Stanislav Kouznetsov
    public void modifierScore(PropertyChangeEvent evt) {
        int scoreActuel = (int) evt.getNewValue();
        lblScore.setText("Score : " + scoreActuel);
    }
}