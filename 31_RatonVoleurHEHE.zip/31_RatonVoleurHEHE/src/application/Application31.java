package application;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import voletInstructionsEtPropos.FenetreAideInstructions;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuItem;

/**
 * Fenêtre principale du jeu
 * 
 * @author Justin Gauthier
 */
public class Application31 extends JFrame {

	private static final long serialVersionUID = 1L;
	/**le panel qui contient les autres elements**/
	private JPanel contentPane;
	/**la fenetre selectionneur de niveau**/
	private Selectionneur selectionneur;
	/**la fenetre editeur de niveau**/
	private Editeur editeur;
	/**la fenetre jouer**/
	private Jouer jouer;
	/**la fenetre magasin**/
	private Magasin magasin;

	/**
	 * Lancer l'application
	 * @param args Arguments de la ligne de commande.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Application31 frame = new Application31();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creer la fenetre
	 */
	//Justin Gauthier
	public Application31() {
		
		editeur = new Editeur();
		jouer = new Jouer();
		magasin = new Magasin();
		selectionneur = new Selectionneur();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1300, 700);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnPropos = new JMenu("À propos");
		mnPropos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		menuBar.add(mnPropos);
		
		
		
		JMenu mnInstructions = new JMenu("Instructions");
		menuBar.add(mnInstructions);
		
		
		FenetreAideInstructions fenInstructions = new FenetreAideInstructions();
		JMenuItem mntmInstructions = new JMenuItem("Instructions du jeu");
		mntmInstructions.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fenInstructions.setVisible(true);
			}
		});
		mnInstructions.add(mntmInstructions);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnJouer = new JButton("Jouer");
		btnJouer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectionneur = new Selectionneur();
				selectionneur.setVisible(true);
				dispose();
			}
		});
		btnJouer.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnJouer.setBounds(480, 221, 230, 30);
		contentPane.add(btnJouer);
		
		JButton btnEditeur = new JButton("Éditeur de niveau");
		btnEditeur.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editeur = new Editeur();
				editeur.setVisible(true);
				dispose();
			}
		});
		btnEditeur.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEditeur.setBounds(480, 367, 230, 30);
		contentPane.add(btnEditeur);
		
		JButton btnQuitter = new JButton("Quitter");
		btnQuitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnQuitter.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnQuitter.setBounds(480, 534, 230, 30);
		contentPane.add(btnQuitter);
		
		JLabel lblTitre = new JLabel("Raton-Voleur");
		lblTitre.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 44));
		lblTitre.setBounds(461, 87, 312, 47);
		contentPane.add(lblTitre);
		
		JCheckBox chckbxEffetsSonores = new JCheckBox("Effets sonores");
		chckbxEffetsSonores.setBounds(1118, 23, 146, 23);
		contentPane.add(chckbxEffetsSonores);
	}
}//fin
