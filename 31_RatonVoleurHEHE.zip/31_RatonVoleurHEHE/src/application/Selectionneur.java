package application;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import composantdessin.JeuPrincipal;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


/**
 * Fenêtre permettant de sélectionner un niveau avant de lancer le jeu.
 * 
 * @author Justin Gauthier
 * @author Stanislav Kouznetsov
 */
public class Selectionneur extends JFrame {

	private static final long serialVersionUID = 1L;

    /** Panneau principal contenant les éléments de l'interface. */
    private JPanel contentPane;

    /** Référence à l'application principale. */
    private Application31 application;

    /** Référence à la fenêtre du jeu. */
    private Jouer jouer;

    /**
     * Lance l'application.
     *
     * @param args Arguments de la ligne de commande.
     */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Selectionneur frame = new Selectionneur();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de la fenêtre.
	 */
	//Justin Gauthier
	public Selectionneur() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1300, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSelectionner = new JLabel("Sélectionnez un niveau");
		lblSelectionner.setFont(new Font("Tahoma", Font.PLAIN, 39));
		lblSelectionner.setBounds(408, 40, 512, 86);
		contentPane.add(lblSelectionner);
		
		JButton btnNiveau1 = new JButton("1");
		btnNiveau1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				niv1();
				jouer = new Jouer();
				jouer.setVisible(true);
				dispose();				
			}
		});
		btnNiveau1.setFont(new Font("Tahoma", Font.PLAIN, 60));
		btnNiveau1.setBounds(90, 237, 300, 300);
		contentPane.add(btnNiveau1);
		
		JButton btnNiveau2 = new JButton("2");
		btnNiveau2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				niv2();
				jouer = new Jouer();
				jouer.setVisible(true);
				dispose();
			}
		});
		btnNiveau2.setFont(new Font("Tahoma", Font.PLAIN, 60));
		btnNiveau2.setBounds(499, 237, 300, 300);
		contentPane.add(btnNiveau2);
		
		JButton btnNiveau3 = new JButton("3");
		btnNiveau3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				niv3();
				jouer = new Jouer();
				jouer.setVisible(true);
				dispose();
			}
		});
		btnNiveau3.setFont(new Font("Tahoma", Font.PLAIN, 60));
		btnNiveau3.setBounds(904, 237, 300, 300);
		contentPane.add(btnNiveau3);
		
		JButton btnMenuPrincipal = new JButton("Menu Principal");
		btnMenuPrincipal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				application = new Application31();
				application.setVisible(true);
				dispose();
			}
		});
		btnMenuPrincipal.setBounds(561, 594, 166, 48);
		contentPane.add(btnMenuPrincipal);
	}
	
	 /**
     * Sélectionne le niveau 1 et met à jour la variable correspondante.
     */
	//Stanislav Kouznetsov
    public void niv1() {
        JeuPrincipal.niveauSelectionne = 1;
    }

    /**
     * Sélectionne le niveau 2 et met à jour la variable correspondante.
     */
    //Stanislav Kouznetsov
    public void niv2() {
        JeuPrincipal.niveauSelectionne = 2;
    }

    /**
     * Sélectionne le niveau 3 et met à jour la variable correspondante.
     */
    //Stanislav Kouznetsov
    public void niv3() {
        JeuPrincipal.niveauSelectionne = 3;
    }

}
