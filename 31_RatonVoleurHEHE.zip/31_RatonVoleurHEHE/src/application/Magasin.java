package application;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.JButton;
import javax.swing.JProgressBar;
import javax.swing.JSlider;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Magasin extends JFrame {

	private static final long serialVersionUID = 1L;
	/**le panel qui contient les autres elements**/
	private JPanel contentPane;
	/**la fenetre jouer**/
	private Jouer jouer;
	/**la fenetre menu principal**/
	private Application31 application;
	/**la fenetre selectionneur**/
	private Selectionneur selectionneur;
	/**la fenetre editeur**/
	private Editeur editeur;

	/**
	 * Lancer l'application
	 * @author Justin Gauthier
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Magasin frame = new Magasin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creer la fenetre
	 */
	//Justin Gauthier
	public Magasin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1300, 700);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnInstructions = new JMenu("Instructions");
		menuBar.add(mnInstructions);
		
		JMenu mnNaviguer = new JMenu("Naviguer");
		menuBar.add(mnNaviguer);
		
		JMenuItem mntmSelecteurNiveau = new JMenuItem("Selectionner un niveau");
		mntmSelecteurNiveau.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectionneur = new Selectionneur();
				selectionneur.setVisible(true);
				dispose();
			}
		});
		mnNaviguer.add(mntmSelecteurNiveau);
		
		JMenuItem mntmEditeurNiveau = new JMenuItem("Éditeur de niveau");
		mntmEditeurNiveau.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editeur = new Editeur();
				editeur.setVisible(true);
				dispose();
			}
		});
		mnNaviguer.add(mntmEditeurNiveau);
		
		JMenuItem mntmMenuPrincipal = new JMenuItem("Menu principal");
		mntmMenuPrincipal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				application = new Application31();
				application.setVisible(true);
				dispose();
			}
		});
		mnNaviguer.add(mntmMenuPrincipal);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblMagasin = new JLabel("Magasin");
		lblMagasin.setFont(new Font("Tahoma", Font.PLAIN, 39));
		lblMagasin.setBounds(514, 37, 159, 69);
		contentPane.add(lblMagasin);
		
		JLabel lblImagePiece = new JLabel("Image piece");
		lblImagePiece.setBackground(new Color(192, 192, 192));
		lblImagePiece.setBounds(10, 24, 99, 44);
		contentPane.add(lblImagePiece);
		
		JLabel lblNbPieces = new JLabel("XXXX");
		lblNbPieces.setBounds(119, 39, 48, 14);
		contentPane.add(lblNbPieces);
		
		JLabel lblImageBoostVertical = new JLabel("Image Boost Vertical");
		lblImageBoostVertical.setBounds(115, 169, 111, 14);
		contentPane.add(lblImageBoostVertical);
		
		JButton btnAcheterBoostVertical = new JButton("Acheter (prix tbd)");
		btnAcheterBoostVertical.setBounds(254, 165, 146, 23);
		contentPane.add(btnAcheterBoostVertical);
		
		JProgressBar progressBarBoostVertical = new JProgressBar();
		progressBarBoostVertical.setBounds(254, 217, 146, 14);
		contentPane.add(progressBarBoostVertical);
		
		JLabel lblForceBoostVertical = new JLabel("Force (N) :");
		lblForceBoostVertical.setBounds(264, 250, 97, 14);
		contentPane.add(lblForceBoostVertical);
		
		JSlider sliderBoostVertical = new JSlider();
		sliderBoostVertical.setBounds(254, 286, 200, 26);
		contentPane.add(sliderBoostVertical);
		
		JLabel lblImageChamp = new JLabel("Image champ electrique");
		lblImageChamp.setBounds(627, 169, 131, 14);
		contentPane.add(lblImageChamp);
		
		JButton btnAcheterChamp = new JButton("Acheter (prix tbd)");
		btnAcheterChamp.setBounds(797, 165, 146, 23);
		contentPane.add(btnAcheterChamp);
		
		JProgressBar progressBarChamp = new JProgressBar();
		progressBarChamp.setBounds(797, 217, 146, 14);
		contentPane.add(progressBarChamp);
		
		JLabel lblForceChamp = new JLabel("Force (N) :");
		lblForceChamp.setBounds(797, 250, 83, 14);
		contentPane.add(lblForceChamp);
		
		JSlider slider = new JSlider();
		slider.setBounds(797, 286, 200, 26);
		contentPane.add(slider);
		
		JLabel lblImageBoostHorizontal = new JLabel("Image Boost Horizontal");
		lblImageBoostHorizontal.setBounds(115, 409, 131, 14);
		contentPane.add(lblImageBoostHorizontal);
		
		JButton btnAcheterBoostHorizontal = new JButton("Acheter (prix tbd)");
		btnAcheterBoostHorizontal.setBounds(254, 405, 146, 23);
		contentPane.add(btnAcheterBoostHorizontal);
		
		JProgressBar progressBarBoostHorizontal = new JProgressBar();
		progressBarBoostHorizontal.setBounds(254, 465, 146, 14);
		contentPane.add(progressBarBoostHorizontal);
		
		JLabel lblForceBoostHorizontal = new JLabel("Force (N) :");
		lblForceBoostHorizontal.setBounds(254, 507, 97, 14);
		contentPane.add(lblForceBoostHorizontal);
		
		JSlider sliderBoostHorizontal = new JSlider();
		sliderBoostHorizontal.setBounds(254, 554, 200, 26);
		contentPane.add(sliderBoostHorizontal);
		
		JLabel lblImageRecharge = new JLabel("Image recharge");
		lblImageRecharge.setBounds(627, 409, 131, 14);
		contentPane.add(lblImageRecharge);
		
		JButton btnAcheterRecharge = new JButton("Acheter (prix tbd)");
		btnAcheterRecharge.setBounds(797, 405, 146, 23);
		contentPane.add(btnAcheterRecharge);
		
		JProgressBar progressBarRecharge = new JProgressBar();
		progressBarRecharge.setBounds(797, 453, 146, 14);
		contentPane.add(progressBarRecharge);
		
		JLabel lblForceRecharge = new JLabel("Force (N) :");
		lblForceRecharge.setBounds(797, 494, 83, 14);
		contentPane.add(lblForceRecharge);
		
		JSlider sliderRecharge = new JSlider();
		sliderRecharge.setBounds(797, 540, 200, 26);
		contentPane.add(sliderRecharge);
		
		JButton btnJouer = new JButton("Jouer");
		btnJouer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jouer = new Jouer();
				jouer.setVisible(true);
				dispose();
			}
		});
		btnJouer.setBounds(1060, 576, 218, 56);
		contentPane.add(btnJouer);
	}
}
