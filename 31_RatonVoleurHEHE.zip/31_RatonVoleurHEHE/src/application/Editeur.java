package application;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import composantdessin.NiveauCustom;
import outils.OutilsImage;

/**
 * @author Justin Gauthier
 * @author Darwinsh Saint-Jean
 */
public class Editeur extends JFrame {

	private static final long serialVersionUID = 1L;
	/** le panel qui contient les autres elements **/
	private JPanel contentPane;
	/** la fenetre jouer **/
	private Jouer jouer;

	private NiveauCustom niveauCustom;

	/** la fenetre du menu principal **/
	private Application31 application;
	private JLabel lblSurvole;
	private JButton btnRoches;
	private JButton btnArbre;
	private JButton btnVoiture;
	private JButton btnBatiment;
	private JButton btnBoostVertical;
	private JButton btnRecharge;
	
	/**
	 * Lancer l'application
	 * 
	 * 
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Editeur frame = new Editeur();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creer la fenetre
	 */
	// Justin Gauthier
	public Editeur() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1300, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBorder(new TitledBorder("Éditeur de niveau"));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		niveauCustom = new NiveauCustom();
		niveauCustom.setBounds(32, 186, 1233, 420);    
	        contentPane.add(niveauCustom);

		JButton btnJouer = new JButton("Jouer");
		btnJouer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jouer = new Jouer();
				jouer.setVisible(true);
				dispose();
			}
		});
		btnJouer.setBounds(720, 607, 137, 33);
		contentPane.add(btnJouer);

		JLabel lblImageRoche_6 = new JLabel("Image Roche");
		lblImageRoche_6.setBounds(979, 28, 113, 82);
		contentPane.add(lblImageRoche_6);

		JLabel lblImageRoche_7 = new JLabel("Image Roche");
		lblImageRoche_7.setBounds(1142, 28, 113, 82);
		contentPane.add(lblImageRoche_7);

		JButton btnMenuPrincipal = new JButton("Menu Principal");
		btnMenuPrincipal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				application = new Application31();
				application.setVisible(true);
				dispose();
			}
		});
		btnMenuPrincipal.setBounds(535, 607, 137, 33);
		contentPane.add(btnMenuPrincipal);

		lblSurvole = new JLabel("");
		lblSurvole.setEnabled(false);
		lblSurvole.setFont(new Font("04b", Font.PLAIN, 23));
		lblSurvole.setBounds(870, 130, 404, 60);
		contentPane.add(lblSurvole);
		
		btnRoches = new JButton("Roche");
		btnRoches.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				niveauCustom.ajouterRoche(); 
			}
		});
		btnRoches.setBounds(32, 28, 142, 155);
		contentPane.add(btnRoches);
		
		btnArbre = new JButton("New button");
		btnArbre.setBounds(184, 28, 142, 155);
		contentPane.add(btnArbre);
		
		btnVoiture = new JButton("New button");
		btnVoiture.setBounds(407, 28, 148, 155);
		contentPane.add(btnVoiture);
		
		btnBatiment = new JButton("New button");
		btnBatiment.setBounds(565, 28, 123, 162);
		contentPane.add(btnBatiment);
		
		btnBoostVertical = new JButton("New button");
		btnBoostVertical.setBounds(845, 28, 124, 155);
		contentPane.add(btnBoostVertical);
		
		btnRecharge = new JButton("New button");
		btnRecharge.setBounds(698, 28, 137, 155);
		contentPane.add(btnRecharge);
		
		ajouterImage();

		ajouterEcouteursSurvol();
	}

	/** Darwinsh Saint-Jean
	public void changementTaille() {
		String tailleChoisi = (String) comboBoxTaille.getSelectedItem();
		System.out.println("taille :" + tailleChoisi);

		switch (tailleChoisi) {

		case "petit":
			niveauCustom.rendrePetit();
			break;

		case "moyen":
			niveauCustom.rendreMoyen();
			break;

		case "grand":
			niveauCustom.rendreGrand();
			break;

		default:
			//
			//
			break;

		}

	} */

	// Darwinsh Saint-jean
	private MouseAdapter creerMouseEvent(String texte) {
		return new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblSurvole.setText("<html>" + texte + "</html>");
			}

			@Override
			public void mouseExited(MouseEvent e) {
				lblSurvole.setText("");
			}
		};
	}

	// Darwinsh Saint-Jean
	private void ajouterEcouteursSurvol() {
	}

	// Darwinsh Saint-Jean
	public void ajouterImage() {
		OutilsImage.lireImageEtPlacerSurBouton("roche.png", btnRoches);
		OutilsImage.lireImageEtPlacerSurBouton("voiture.png", btnVoiture);
		OutilsImage.lireImageEtPlacerSurBouton("arbre.png", btnArbre);
		OutilsImage.lireImageEtPlacerSurBouton("batiment.png", btnBatiment);
		OutilsImage.lireImageEtPlacerSurBouton("boostVertical.png", btnBoostVertical);
		OutilsImage.lireImageEtPlacerSurBouton("recharge.png", btnRecharge);
	}
}
