package geometrieDessin;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

/**
 * La barre de newtons qui s'affiche en haut de la scène du jeu
 * @author Justin Gauthier
 */
public class BarreNewtons {
	/**La longueur de la barre**/
	private double longueur;
	/**la coordonnée en x du coin supérieur gauche de la barre**/
	private double x;
	/**la coordonnée en x du coin supérieur gauche de la barre**/
	private double y;
	/**Le facteur de consommation de la barre**/
	private double consommationBarre = 1;
	/**Le rectangle qui delimite la barre**/
	private Rectangle2D.Double barre;
	/**Le rectangle qui delimite la bordure**/
	private Rectangle2D.Double bordure;
	/**La hauteur de la barre**/
	private final double HAUTEUR_BARRE = 0.25;
	/**Le nombre de pixels par metre de la barre**/
	private double pixelsParMetre = 1;
	
	/**
	 * Le constructeur de la barre de newtons
	 * @param x la coordonnée en x du coin supérieur gauche de la barre
	 * @param y la coordonnée en y du coin supérieur gauche de la barre
	 * @param longueur la longueur de la barre
	 */
	//Justin Gauthier
	public BarreNewtons(double x, double y, double longueur) {
		this.longueur = longueur;
		this.x = x;
		this.y = y;
		creerLaGeometrie();
	}
	
	/**
	 * Creer la geometrie de la barre
	 */
	//Justin Gauthier
	private void creerLaGeometrie(){
		bordure = new Rectangle2D.Double(x, y, longueur, HAUTEUR_BARRE);
		barre = new Rectangle2D.Double(x, y, longueur*this.consommationBarre, HAUTEUR_BARRE);
	}
	
	/**
	 * Dessiner les differents rectangles de la barre
	 * @param g2d le contexte graphique
	 */
	//Justin Gauthier
	public void dessiner(Graphics2D g2d) {
		Graphics2D g2dPrive = (Graphics2D) g2d.create();
		g2dPrive.scale(pixelsParMetre, pixelsParMetre);
		g2dPrive.setColor(Color.green);
		g2dPrive.fill(barre);
		g2dPrive.setStroke(new BasicStroke((float) (2/pixelsParMetre)));
		g2dPrive.setColor(Color.black);
		g2dPrive.draw(bordure);
		
	}
	
	/**
	 * Modifie le facteur permettant de passer des metres aux pixels lors du dessin
	 * Ainsi on peut exprimer tout en m,  m/s  et m/s2
	 * @param pixelsParMetre Facteur de mise à l'échelle lors du dessin
	 */
	//Justin Gauthier
	public void setPixelsParMetre(double pixelsParMetre) {
		this.pixelsParMetre = pixelsParMetre;
	}
	
	/**
	 * Modifier le facteur de consommation de la barre
	 * @param consummation la consommation de la barre, entre 0 et 1;
	 */
	//Justin Gauthier
	public void consommerBarre(double consummation) {
		this.consommationBarre = this.consommationBarre - consummation;
		creerLaGeometrie();
	}
	
	/**
	 * permet d'obtenir la consommation disponible restante de la barre
	 * @return la consommation restante de la barre
	 */
	//Justin Gauthier
	public double getConsommationRestante() {
		return this.consommationBarre;
	}
	
	
	
	
	
	
}
