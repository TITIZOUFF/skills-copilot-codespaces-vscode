package physique;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import geometrieDessin.Vecteur2D;

/**
 * Gère les événements physiques du jeu en calculant et en mettant à jour 
 * les paramètres physiques tels que l'accélération, la vitesse, la position et la force gravitationnelle.
 * 
 * IMPORTANT: Cette classe est encore à modifié, ceci est juste un exemple et donc c'est normal qu'il y a autant de code inutile
 * 
 * @author Stanislav Kouznetsov
 */
public class GestionnaireEvenementsPhysique {
    
    /** Support pour la gestion des événements liés aux propriétés physiques. */
    private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    
    /** Instance du moteur physique utilisé pour les calculs. */
    private final MoteurPhysique moteurPhysique;
    
    /** Accélération actuelle. */
    private Vecteur2D acceleration = new Vecteur2D(0, 0);
    
    /** Vitesse actuelle. */
    private Vecteur2D vitesse = new Vecteur2D(0, 0);
    
    /** Position actuelle. */
    private Vecteur2D position = new Vecteur2D(0, 0);
    
    /** Force gravitationnelle actuelle. */
    private Vecteur2D forceGrav = new Vecteur2D(0, 0);

    /**
     * Initialise le gestionnaire avec un moteur physique.
     * @param moteurPhysique Le moteur physique utilisé pour les calculs.
     */
    //Stanislav Kouznetsov
    public GestionnaireEvenementsPhysique(MoteurPhysique moteurPhysique) {
        this.moteurPhysique = moteurPhysique;
    }

    /**
     * Ajoute un écouteur d'événements pour les changements de propriété.
     * @param listener L'écouteur à ajouter.
     */
  //Stanislav Kouznetsov
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(listener);
    }

    /**
     * Supprime un écouteur d'événements.
     * @param listener L'écouteur à supprimer.
     */
  //Stanislav Kouznetsov
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        pcs.removePropertyChangeListener(listener);
    }

    /**
     * Calcule et met à jour l'accélération en fonction de la somme des forces et de la masse.
     * @param sommeDesForces La somme des forces appliquées.
     * @param masse La masse de l'objet.
     * @return L'accélération calculée.
     * @throws Exception Si un problème survient dans le calcul.
     */
  //Stanislav Kouznetsov
    public Vecteur2D calculAcceleration(Vecteur2D sommeDesForces, double masse) throws Exception {
        acceleration = moteurPhysique.calculAcceleration(sommeDesForces, masse);
        pcs.firePropertyChange("acceleration", null, acceleration);
        return acceleration;
    }

    /**
     * Calcule et met à jour la vitesse en fonction du temps et de l'accélération.
     * @param deltaT L'intervalle de temps.
     * @param vitesse La vitesse actuelle.
     * @param accel L'accélération actuelle.
     * @return La vitesse calculée.
     */
  //Stanislav Kouznetsov
    public Vecteur2D calculVitesse(double deltaT, Vecteur2D vitesse, Vecteur2D accel) {
        this.vitesse = moteurPhysique.calculVitesse(deltaT, vitesse, accel);
        pcs.firePropertyChange("vitesse", null, this.vitesse);
        return this.vitesse;
    }

    /**
     * Calcule et met à jour la position en fonction du temps et de la vitesse.
     * @param deltaT L'intervalle de temps.
     * @param position La position actuelle.
     * @param vitesse La vitesse actuelle.
     * @return La nouvelle position.
     */
  //Stanislav Kouznetsov
    public Vecteur2D calculPosition(double deltaT, Vecteur2D position, Vecteur2D vitesse) {
        this.position = moteurPhysique.calculPosition(deltaT, position, vitesse);
        pcs.firePropertyChange("position", null, this.position);
        return this.position;
    }

    /**
     * Calcule et met à jour la force gravitationnelle en fonction de la masse.
     * @param masse La masse de l'objet.
     * @return La force gravitationnelle calculée.
     */
  //Stanislav Kouznetsov
    public Vecteur2D calculForceGrav(double masse) {
        this.forceGrav = moteurPhysique.calculForceGrav(masse);
        pcs.firePropertyChange("forceGrav", null, this.forceGrav);
        return this.forceGrav;
    }
    
    /** @return L'accélération actuelle. */
  //Stanislav Kouznetsov
    public Vecteur2D getAcceleration() {
        return acceleration;
    }

    /** @return La vitesse actuelle. */
  //Stanislav Kouznetsov
    public Vecteur2D getVitesse() {
        return vitesse;
    }

    /** @return La position actuelle. */
  //Stanislav Kouznetsov
    public Vecteur2D getPosition() {
        return position;
    }

    /** @return La force gravitationnelle actuelle. */
  //Stanislav Kouznetsov
    public Vecteur2D getForceGrav() {
        return forceGrav;
    }

    /** @return Composante X de l'accélération. */
  //Stanislav Kouznetsov
    public double getAccelerationX() {
        return acceleration.getX();
    }

    /** @return Composante Y de l'accélération. */
  //Stanislav Kouznetsov
    public double getAccelerationY() {
        return acceleration.getY();
    }

    /** @return Composante X de la vitesse. */
  //Stanislav Kouznetsov
    public double getVitesseX() {
        return vitesse.getX();
    }

    /** @return Composante Y de la vitesse. */
  //Stanislav Kouznetsov
    public double getVitesseY() {
        return vitesse.getY();
    }

    /** @return Composante X de la position. */
  //Stanislav Kouznetsov
    public double getPositionX() {
        return position.getX();
    }

    /** @return Composante Y de la position. */
  //Stanislav Kouznetsov
    public double getPositionY() {
        return position.getY();
    }

    /** @return Composante X de la force gravitationnelle. */
  //Stanislav Kouznetsov
    public double getForceGravX() {
        return forceGrav.getX();
    }

    /** @return Composante Y de la force gravitationnelle. */
  //Stanislav Kouznetsov
    public double getForceGravY() {
        return forceGrav.getY();
    }
}
