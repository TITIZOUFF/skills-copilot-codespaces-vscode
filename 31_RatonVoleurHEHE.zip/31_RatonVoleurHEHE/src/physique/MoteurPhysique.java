package physique;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;

import ameliorations.BoostHorizontal;
import geometrieDessin.Vecteur2D;
import java.awt.geom.Rectangle2D;
import obstacles.Sapin;
/**
 * Cette classe regroupera les calculs physiques n�cessaires au mouvement des objets
 * des divers objets dans la sc�ne.
 * Utilise la m�thode n'int�gration num�rique d'Euler semi-implicite. 
 *  
 * @author Edson François Gertilus
 * @author Darwinsh Saint-Jean
 *
 */
public class MoteurPhysique  {

	private static final double ACCEL_G = 9.80665;
	private static final double EPSILON = 1e-10; //tolerance utilisee dans les comparaisons reelles avec zero
	private static final double test=0.5;
	//private static final double	q = 1.6 * Math.pow(10, -19);
	public static final double K_COULOMB =  9e9;;


	/**
	 * Calcule et retourne l'acceleration en utilisant F=ma
	 * @param sommeDesForces Somme des forces appliquees
	 * @param masse Masse del'objet
	 * @return l'acceletation F/m
	 * @throws Exception Erreur si la masse est pratiquement nulle
	 */
	//Darwinsh Saint-Jean
	public static Vecteur2D calculAcceleration(Vecteur2D sommeDesForces, double masse) throws Exception { 
		if(masse < EPSILON) 
			throw new Exception("Erreur MoteurPhysique: La masse �tant nulle ou presque l'acc�leration ne peut pas etre calcul�e.");
		else
			return new Vecteur2D( sommeDesForces.getX()/masse , sommeDesForces.getY()/masse );	
	}

	/**
	 * Calcule et retourne la nouvelle vitesse, deltaT secondes plus tard, en utilisant l'algorithme
	 * d'Euler semi-implicite.
	 * @param deltaT L'intervalle de temps (petit!) en secondes
	 * @param vitesse La vitesse initiale au debut de l'intervalle de temps, en m/s
	 * @param accel L'acceleration initiale au debut de l'intervalle de temps, en m/s2
	 * @return La nouvelle vitesse (a la fin de l'intervalle)
	 */
	//Edson François Gertilus
	public static Vecteur2D calculVitesse(double deltaT, Vecteur2D vitesse, Vecteur2D accel) {
		Vecteur2D deltaVitesse = Vecteur2D.multiplie(accel, deltaT);
		Vecteur2D resultVit = vitesse.additionne( deltaVitesse );
		return new Vecteur2D(resultVit.getX(), resultVit.getY());

	}
	/**
	 * Calcule et retourne la nouvelle position, deltaT secondes plus tard, en utilisant l'algorithme
	 * d'Euler semi-implicite.
	 * @param deltaT L'intervalle de temps (petit!) en secondes
	 * @param position La position initiale au debut de l'intervalle de temps, en m
	 * @param vitesse La vitesse initiale au debut de l'intervalle de temps, en m/s
	 * @return La nouvelle position (a la fin de l'intervalle)
	 * 
	 */
	//Edson François Gertilus
	public static Vecteur2D calculPosition(double deltaT, Vecteur2D position, Vecteur2D vitesse) {
		Vecteur2D deltaPosition = Vecteur2D.multiplie(vitesse, deltaT);
		Vecteur2D resultPos = position.additionne(deltaPosition); 
		return new Vecteur2D(resultPos.getX(), resultPos.getY());
	}
	/**
	 * Cette méthode a pour but d'appliquer à la collision un boostHorizontal
	 * @param vitesse La vitesse initiale au debut de l'intervalle de temps, en m/s
	 * @return La nouvelle vitesse
	 * 
	 */
	//Edson François Gertilus
	public static Vecteur2D appliquerBoostHorizontal(Vecteur2D vitesse) {
		double BOOST_HORIZONTAL = 3.0;
		vitesse.setX(vitesse.getX() + BOOST_HORIZONTAL);
		return vitesse;
	}

	public static Vecteur2D appliquerBoostVertical(Vecteur2D vitesse) {
		double BOOST_VERTICAL = 3.0;
		vitesse.setY(vitesse.getY() + BOOST_VERTICAL);
		return vitesse;
	}


	/**
	 * Forme et retourne un vecteur exprimant la force gravitationnelle s'appliquant sur un objet dont la masse est passee en parametre
	 * @param masse Masse de l'objet
	 * @return Un vecteur repr�sentant la force gravitationnelle exercee
	 */
	//Edson François Gertilus
	public static Vecteur2D calculForceGrav(double masse) {
		return new Vecteur2D( 0, ACCEL_G*masse);
	}

	/**
	 * Calcule et retourne le temps total en secondes que l'objet passe en l'air avant de toucher le sol.
	 *
	 * @param vitesseInitiale Intensité de la vitesse initiale de l'objet (en m/s)
	 * @param angle Angle de lancement en degrés (par rapport à l'horizontale)
	 * @return Le temps total en secondes avant que l'objet touche le sol
	 */
	//Darwinsh Saint-Jean
	public static double calculTempsEnAir(double vitesseInitiale, double angle) {
		double angleLancement = Math.toRadians(angle); // Conversion en radians
		double v0y = vitesseInitiale * Math.sin(angleLancement); // Composante verticale de la vitesse initiale

		return (v0y) / ACCEL_G; // Temps total
	}

	//public static boolean collisionCercleCercle(Vecteur2D centre1, double rayon1, Vecteur2D centre2, double rayon2) {

	//	double distX = centre1.getX() - centre2.getX();// peut-être je vais le faire en float
	//double distY = centre1.getY() - centre2.getY();
	//double distance = Math.sqrt(distX * distX + distY * distY);

	//return distance <= rayon1 + rayon2;
	//}
	//Si c'Est vrai il y aura des modifications dans la vitesse mais je ne peux pas encore les faire parce que j'ai pas d'animation
	//public static boolean collisionCercleRectangle(Vecteur2D centreCercle, double rayon, Vecteur2D coinRectangle, double largeur, double hauteur) {		
	//	double rectX = coinRectangle.getX();
	//double rectY = coinRectangle.getY();
	//	double rectX2 = rectX + largeur;  
	//double rectY2 = rectY + hauteur;  
	//Evidemment le premier coté est est le plus proche de la collsion
	//	double procheY = centreCercle.getY();

	//		procheX = rectX;  
	//} else if (centreCercle.getX() > rectX2) {
	//		procheX = rectX2;
	//}
	//
	//if (centreCercle.getY() < rectY) {
	//	procheY = rectY; 
	//	} else if (centreCercle.getY() > rectY2) {
	//	procheY = rectY2; 
	//	}
	//double distX = centreCercle.getX() - procheX;
	//	double distY = centreCercle.getY() - procheY;
	//double distance = Math.sqrt(distX * distX + distY * distY);

	//return distance <= rayon;
	//	}
	//Si c'Est vrai il y aura des modifications dans la vitesse mais je ne peux pas encore les faire parce que j'ai pas d'animation

	/**Permet de calculer la force électrique de manière théorique
	 * 
	 * 
	 * @param positionRaton c'est l'endroit où est situé le raton
	 * @param  positionCharge2 c'est l'endroit où est situé le  deuxième objet
	 * @param chargeRaton  c'est la charge du raton
	 * @param charge2 c'est la charge du deuxième objet
	 * @return  le vecteur qui comporte les forces en x et y 
	 *
	 */ 
	//Edson François Gertilus
	public static Vecteur2D calculForceElectriquePhysique1(Vecteur2D positionRaton, double chargeRaton, Vecteur2D positionCharge2, double charge2) {
		double k = 9e9;
		double distanceX = positionCharge2.getX() - positionRaton.getX();
		double distanceY = positionCharge2.getY() - positionRaton.getY();
		double r = Math.sqrt(distanceX * distanceX + distanceY * distanceY);
		if (r < 0.1) {
			r = 0.1; // Distance minimale de 0.1 mètre
		}

		// Éviter une division par zéro
		if (r < EPSILON) {
			return new Vecteur2D(0, 0);
		}
		double facteurEchelle = 1e-20;
		double magnitudeForce = (k * chargeRaton * charge2) / (r * r);
		double forceX = facteurEchelle * magnitudeForce * (distanceX / r);
		double forceY = facteurEchelle * magnitudeForce * (distanceY / r);
		// Limiter la force pour éviter des boosts énormes


		return new Vecteur2D(forceX, forceY);
	}
	//	public static boolean collisionCercleSapin(Vecteur2D centreCercle, double rayon, Sapin sapin) {


	// double x = sapin.getX();
	//   double largeur = sapin.getlongeurSapin();
	// double hauteur = sapin.getHauteurSapin();


	//    Vecteur2D[] extremite = {            //Ici pour trouver tout les points au extrémité du sapin 
	//       new Vecteur2D(x, y + hauteur),                     
	//      new Vecteur2D(x + largeur, y + hauteur),         
	//  new Vecteur2D(x + largeur/2, y)   
	// };	
	// return collisionCercleSapin(centreCercle, rayon, extremite);
	
	
	/**Permet d'utilisé la loi de Coulomb pour représenter visuellement l'attraction
	 * 
	 * 
	 * @param x1 c'est l'endroit où est situé le raton
	 * @param  x2 c'est l'endroit où est situé le  deuxième objet
	 * @param q1 c'est la charge du raton
	 * @param q2 c'est la charge du deuxième objet
	 * @return les forces en x et y
	 *
	 */ 
	public static double[] calculForceElectrique(double x1, double y1, double q1, double x2, double y2, double q2) {
		double k = 8.99e9; // Constante de Coulomb
		double dx = x2 - x1;
		double dy = y2 - y1;
		double distance = Math.sqrt(dx * dx + dy * dy);
		if (distance < 1.0) distance = 1.0;
		double force = k * Math.abs(q1 * q2) / (distance * distance);
		double fx = force * dx / distance; 
		double fy = force * dy / distance; 
		return new double[] {fx, fy};
	}

public static Vecteur2D calculForceElectriquePhysique(Vecteur2D positionRaton, double chargeRaton, Vecteur2D positionChamp, double chargeChamp) {
    // Constante de Coulomb
    double k = K_COULOMB; // Utilise la constante définie dans la classe
    
    // Calcul des distances
    double distanceX = positionChamp.getX() - positionRaton.getX();
    double distanceY = positionChamp.getY() - positionRaton.getY();
    double distanceCarree = distanceX * distanceX + distanceY * distanceY;
    
    // Éviter division par zéro
    if (distanceCarree < EPSILON) {
        return new Vecteur2D(0, 0);
    }
    
    // Calcul de la distance réelle
    double distance = Math.sqrt(distanceCarree);
    
    // Facteur d'échelle pour avoir une force visible dans le jeu
    // Tu peux ajuster cette valeur pour renforcer ou affaiblir l'effet
    double facteurEchelle = 1e-10;
    
    // Calcul de la magnitude de la force selon la loi de Coulomb
    double magnitudeForce = (k * Math.abs(chargeRaton * chargeChamp)) / distanceCarree;
    
    // Direction de la force (attraction si charges opposées, répulsion si identiques)
    int direction = (chargeRaton * chargeChamp < 0) ? 1 : -1;
    
    // Composantes de la force
    double forceX = direction * facteurEchelle * magnitudeForce * (distanceX / distance);
    double forceY = direction * facteurEchelle * magnitudeForce * (distanceY / distance);
    
    return new Vecteur2D(forceX, forceY);
}
}



