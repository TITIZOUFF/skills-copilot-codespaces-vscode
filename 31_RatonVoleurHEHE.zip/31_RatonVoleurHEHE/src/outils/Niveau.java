package outils;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;

import ameliorations.BoostHorizontal;
import ameliorations.BoostVertical;
import ameliorations.Champ;
import ameliorations.Recharge;
import geometrieDessin.Vecteur2D;
import obstacles.Batiment;
import obstacles.Roche;
import obstacles.Sapin;
import obstacles.Voiture;
import personnage.Raton;
import physique.MoteurPhysique;

public class Niveau {

	/**La largeur du niveau**/
	private double largeur;
	/**La hauteur du niveau**/
	private double hauteur;
	/**Liste qui mémorise tous les batiments d'un niveau**/
	private ArrayList<Batiment> batiments;
	/**Liste qui mémorise toutes les voitures d'un niveau**/
	private ArrayList<Voiture> voitures;
	/**Liste qui mémorise toutes les roches d'un niveau**/
	private ArrayList<Roche> roches;
	/**Liste qui mémorise tous les sapins d'un niveau**/
	private ArrayList<Sapin> sapins;
	/**Liste qui mémorise tous les boost horizontal d'un niveau**/
	private ArrayList<BoostHorizontal> boostHorizontal;
	/**Liste qui mémorise tous boost vertical d'un niveau**/
	private ArrayList<BoostVertical> boostVertical;
	/**Liste qui mémorise tous les champs d'un niveau**/
	private ArrayList<Champ> champs;
	/**Liste qui mémorise toutes les recharges d'un niveau**/
	private ArrayList<Recharge> recharges;
	
	/**Constructeur du niveau
	 * 
	 * @param largeur la largeur du niveau
	 * @param hauteur la hauteur du niveau
	 */
	//Justin Gauthier
	public Niveau (double largeur, double hauteur) {
		this.largeur = largeur;
		this.hauteur = hauteur;

		this.batiments = new ArrayList<Batiment>();
		this.voitures = new ArrayList<Voiture>();
		this.roches = new ArrayList<Roche>();
		this.sapins = new ArrayList<Sapin>();
		this.boostHorizontal = new ArrayList<BoostHorizontal>();
		this.boostVertical = new ArrayList<BoostVertical>();
		this.champs = new ArrayList<Champ>();
		this.recharges = new ArrayList<Recharge>();
	}

	/**Ajouter un batiment au niveau
	 * 
	 * @param batiment le batiment qu'on souhaite ajouter
	 */
	//Justin Gauthier
	public void ajouterBatiment(Batiment batiment) {
		batiments.add(batiment);

	}

	/**Ajouter une voiture au niveau
	 * 
	 * @param voiture la voiture qu'on souhaite ajouter
	 */
	//Justin Gauthier
	public void ajouterVoiture(Voiture voiture) {
		voitures.add(voiture);
	}

	/**Ajouter une roche au niveau
	 * 
	 * @param roche la roche qu'on souhaite ajouter
	 */
	//Justin Gauthier
	public void ajouterRoche(Roche roche) {
		roches.add(roche);
	}

	/**Ajouter un sapin au niveau
	 * 
	 * @param sapin le sapin qu'on souhaite ajouter
	 */
	//Justin Gauthier
	public void ajouterSapin(Sapin sapin) {
		sapins.add(sapin);
	}

	/**Ajouter un boost horizontal au niveau
	 * 
	 * @param boost le boost horizontal qu'on souhaite ajouter
	 */
	//Justin Gauthier
	public void ajouterBoostHorizontal(BoostHorizontal boost) {
		boostHorizontal.add(boost);
	}

	/**Ajouter un boost vertical au niveau
	 * 
	 * @param boost le boost vertical qu'on souhaite ajouter
	 */
	//Justin Gauthier
	public void ajouterBoostVertical(BoostVertical boost) {
		boostVertical.add(boost);
	}

	/**Ajouter un champ au niveau
	 * 
	 * @param champ le champ qu'on souhaite ajouter
	 */
	//Justin Gauthier
	public void ajouterChamp(Champ champ) {
		champs.add(champ);
	}

	/**Ajouter une recharge au niveau
	 * 
	 * @param recharge la recharge qu'on souhaite ajouter
	 */
	//Justin Gauthier
	public void ajouterRecharge(Recharge recharge) {
		recharges.add(recharge);
	}

	/**Permet de dessiner tous les obstacles et toutes les ameliorations memorisees dans un niveau
	 * 
	 * @param g2d le contexte graphique
	 */
	//Justin Gauthier
	public void dessinerObstacles(Graphics2D g2d) {
		for(int i=0;i<batiments.size();i++) {
			Batiment batimentDessin = batiments.get(i);
			batimentDessin.dessiner(g2d);
		}

		for(int i=0;i<voitures.size();i++) {
			Voiture voitureDessin = voitures.get(i);
			voitureDessin.dessiner(g2d);
		}

		for(int i=0;i<roches.size();i++) {
			Roche rocheDessin = roches.get(i);
			rocheDessin.dessiner(g2d);
		}

		for(int i=0;i<sapins.size();i++) {
			Sapin sapinDessin = sapins.get(i);
			sapinDessin.dessiner(g2d);
		}

		for(int i=0;i<boostHorizontal.size();i++) {
			BoostHorizontal boostHorizontalDessin = boostHorizontal.get(i);
			boostHorizontalDessin.dessiner(g2d);
		}

		for(int i=0;i<boostVertical.size();i++) {
			BoostVertical boostVerticalDessin = boostVertical.get(i);
			boostVerticalDessin.dessiner(g2d);
		}

		for(int i=0;i<champs.size();i++) {
			Champ champDessin = champs.get(i);
			champDessin.dessiner(g2d);
		}

		for(int i=0;i<recharges.size();i++) {
			Recharge rechargeDessin = recharges.get(i);
			rechargeDessin.dessiner(g2d);
		}
	}

	/**Permet de deplacer tous les obstacles et ameliorations memorises d'un certain increment
	 * 
	 * @param increment l'increment de deplacement
	 */
	//Justin Gauthier
	public void deplacerObstacles(double increment) {
		for(int i=0;i<batiments.size();i++) {
			Batiment batimentDessin = batiments.get(i);
			batimentDessin.deplacerBatiment(increment);
			batiments.set(i, batimentDessin);
		}

		for(int i=0;i<voitures.size();i++) {
			Voiture voitureDessin = voitures.get(i);
			voitureDessin.deplacerVoiture(increment);
			voitures.set(i, voitureDessin);
		}

		for(int i=0;i<roches.size();i++) {
			Roche rocheDessin = roches.get(i);
			rocheDessin.deplacerRoche(increment);
			roches.set(i, rocheDessin);
		}

		for(int i=0;i<sapins.size();i++) {
			Sapin sapinDessin = sapins.get(i);
			sapinDessin.deplacerSapin(increment);
			sapins.set(i, sapinDessin);
		}

		for(int i=0;i<boostHorizontal.size();i++) {
			BoostHorizontal boostHorizontalDessin = boostHorizontal.get(i);
			boostHorizontalDessin.deplacerBoost(increment);
			boostHorizontal.set(i, boostHorizontalDessin);
		}

		for(int i=0;i<boostVertical.size();i++) {
			BoostVertical boostVerticalDessin = boostVertical.get(i);
			boostVerticalDessin.deplacerBoost(increment);
			boostVertical.set(i, boostVerticalDessin);
		}

		for(int i=0;i<champs.size();i++) {
			Champ champDessin = champs.get(i);
			champDessin.deplacerChamp(increment);
			champs.set(i, champDessin);
		}

		for(int i=0;i<recharges.size();i++) {
			Recharge rechargeDessin = recharges.get(i);
			rechargeDessin.deplacerRecharge(increment);
			recharges.set(i, rechargeDessin);
		}
	}
	/**Permet de tester la collision du batiment
	 * 
	 * @param raton le raton de la classe raton
	 */
	//Edson François Gertilus
	public void testerCollisionsBatiment(Raton raton){
		for (Batiment batiment : batiments) {
			raton.gererCollisionBatiment(batiment);
		}
	}
	/**Permet de tester la collision de la roche
	 * 
	 * @param raton le raton de la classe raton
	 */
	//Edson François Gertilus
	public void testerCollisionsRoche(Raton raton) {
		for(int i=0;i<roches.size();i++) {
			//roches.get(i).checkCollision(new Ellipse2D.Double(raton.getX(), raton.getY(), raton.getRayon()*2, raton.getRayon()*2 ));
			for (Roche roche : roches) {
				raton.gererCollisionRoche(roche);
			}
		}
	}
	/**Permet de tester la collision du sapin
	 * 
	 * @param raton le raton de la classe raton
	 * @throws Exception 
	 */
	//Edson François Gertilus
	public void testerCollisionsSapin(Raton raton) throws Exception {
		for(int i=0;i<sapins.size();i++) {
			//sapins.get(i).checkCollision(new Ellipse2D.Double(raton.getX(), raton.getY(), raton.getRayon()*2, raton.getRayon()*2 ));
			for (Sapin sapin : sapins) {
				raton.gererCollisionSapin(sapin);
			}
		}
	}
	/**Permet de tester la collision de la voiture
	 * 
	 * @param raton le raton de la classe raton
	 */
	//Edson François Gertilus


	/**Permet de tester la collision du boostHorizontal
	 * 
	 * @param raton le raton de la classe raton
	 */
	//Edson François Gertilus
	public void testerCollisionsBoostHorizontal(Raton raton) {
		for(int i=0;i< boostHorizontal.size();i++) {
			for (BoostHorizontal BoostHorizontal: boostHorizontal) {
				raton.gererCollisionBoostHorizontal(BoostHorizontal);
			}
		}
	}

	/**Permet de tester la collision du boostVertical
	 * 
	 * @param raton le raton de la classe raton
	 */
	//Edson François Gertilus
	public void testerCollisionsBoostVertical(Raton raton) {
		for(int i=0;i< boostVertical.size();i++) {
			for (BoostVertical BoostVertical: boostVertical) {
				raton.gererCollisionBoostVertical(BoostVertical);
			}
		}
	}



	/**Permet de tester la collision du champ
	 * 
	 * @param raton le raton de la classe raton
	 */
	//Edson François Gertilus
	public void testerCollisionsChamp(Raton raton) throws Exception {
		for (Champ champ : champs) {
			raton.gererCollisionChamp(champ);
			}
		}
	
	
	public void testerCollisionsRecharge(Raton raton) {
		for(int i=0;i<recharges.size();i++) {
			boolean collision = recharges.get(i).checkCollision(new Ellipse2D.Double(raton.getX(), raton.getY(), raton.getRayon()*2, raton.getRayon()*2 ));
			if (collision) {
				//
			}
		}
	}

	public void setPixelsParMetre(double pixelsParMetre) {
		for(int i=0;i<batiments.size();i++) {
			Batiment batimentDessin = batiments.get(i);
			batimentDessin.setPixelsParMetre(pixelsParMetre);
			batiments.set(i, batimentDessin);
		}

		for(int i=0;i<voitures.size();i++) {
			Voiture voitureDessin = voitures.get(i);
			voitureDessin.setPixelsParMetre(pixelsParMetre);
			voitures.set(i, voitureDessin);
		}

		for(int i=0;i<roches.size();i++) {
			Roche rocheDessin = roches.get(i);
			rocheDessin.setPixelsParMetre(pixelsParMetre);
			roches.set(i, rocheDessin);
		}

		for(int i=0;i<sapins.size();i++) {
			Sapin sapinDessin = sapins.get(i);
			sapinDessin.setPixelsParMetre(pixelsParMetre);
			sapins.set(i, sapinDessin);
		}

		for(int i=0;i<boostHorizontal.size();i++) {
			BoostHorizontal boostDessin = boostHorizontal.get(i);
			boostDessin.setPixelsParMetre(pixelsParMetre);
			boostHorizontal.set(i, boostDessin);
		}

		for(int i=0;i<boostVertical.size();i++) {
			BoostVertical boostDessin = boostVertical.get(i);
			boostDessin.setPixelsParMetre(pixelsParMetre);
			boostVertical.set(i, boostDessin);
		}

		for(int i=0;i<champs.size();i++) {
			Champ champDessin = champs.get(i);
			champDessin.setPixelsParMetre(pixelsParMetre);
			champs.set(i, champDessin);
		}

		for(int i=0;i<recharges.size();i++) {
			Recharge rechargeDessin = recharges.get(i);
			rechargeDessin.setPixelsParMetre(pixelsParMetre);
			recharges.set(i, rechargeDessin);
		}
	}

}
