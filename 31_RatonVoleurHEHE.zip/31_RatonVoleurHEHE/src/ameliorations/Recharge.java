 package ameliorations;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import geometrieDessin.Vecteur2D;
import outils.Dessinable;
import outils.OutilsImage;

/**
 * Recharge de newtons qui permet de recharger la barre de newtons
 * @author Justin Gauthier
 */
public class Recharge implements Dessinable{

	/**Vecteur de la position de la recharge**/
	private Vecteur2D position;
	/**longueur d'un cote de la recharge**/
	private final double COTE = 0.5;
	/**Carre qui delimite la recharge**/
	private Rectangle2D.Double recharge;
	/**Le nombre de pixels par metre de la recharge**/
	private double pixelsParMetre =1;
	private Image image = OutilsImage.lireImage("recharge.png");
	
	/**Constructeur de la recharge
	 * 
	 * @param position le vecteur de la position de la recharge
	 */
	//Justin Gauthier
	public Recharge(Vecteur2D position) {
		this.position = position;
		creerLaGeometrie();
	}
	
	/**Creer la forme qui delimite la recharge**/
	//Justin Gauthier
	private void creerLaGeometrie() {
		recharge = new Rectangle2D.Double(position.getX(), position.getY(), COTE, COTE);
	}

	/**Dessiner la recharge
	 * 
	 * @param g2d le contexte graphique
	 */
	//Justin Gauthier
	@Override
	public void dessiner(Graphics2D g2d) {
		Graphics2D g2dPrive = (Graphics2D) g2d.create();
		g2dPrive.scale(pixelsParMetre, pixelsParMetre);
		g2dPrive.setColor(Color.LIGHT_GRAY);
		g2dPrive.fill(recharge);
		/*/g2d.scale((1/pixelsParMetre), (1/pixelsParMetre));
		g2dPrive.drawImage(image, (int)(position.getX()*pixelsParMetre), (int)(position.getY()*pixelsParMetre), (int)(COTE*pixelsParMetre), (int)(COTE*pixelsParMetre), null);
		/*/
	}
	
	
	/**Permet d'obtenir la position en x de la recharge
	 * 
	 * @return la position en x de la recharge
	 */
	//Justin Gauthier
	public double getX() {
		return position.getX();
	}
	
	/**Permet d'obtenir la position en y de la recharge
	 * 
	 * @return la position en y de la recharge
	 */
	//Justin Gauthier
	public double getY() {
		return position.getY();
	}
	
	/**Vérifie si la recharge est en collision avec le personnage selon sa position actuelle
	 * 
	 * @param perso le cercle qui delimite le personnage
	 * @return si il y a collision ou non
	 */
	//Justin Gauthier
	public boolean checkCollision(Ellipse2D.Double perso) {
		Area airePerso = new Area(perso);
		Rectangle2D.Double recharge = new Rectangle2D.Double(this.getX(), this.getY(), COTE, COTE);
		Area aireRecharge = new Area(recharge);
		airePerso.intersect(aireRecharge);
		if(airePerso.isEmpty()) {
			return false;
		}else {
			return true;
		}
	}
	
	/**Permet de déplacer la recharge en x
	 * 
	 * @param increment l'increment de deplacement de la recharge
	 */
	//Justin Gauthier
	public void deplacerRecharge(double increment) {
		this.position.setX(this.position.getX()-increment);
		creerLaGeometrie();
	}
	
	/**
	 * Modifie le facteur permettant de passer des metres aux pixels lors du dessin
	 * Ainsi on peut exprimer tout en m,  m/s  et m/s2
	 * @param pixelsParMetre Facteur de mise à l'échelle lors du dessin
	 */
	//Justin Gauthier
	public void setPixelsParMetre(double pixelsParMetre) {
		this.pixelsParMetre = pixelsParMetre;
		
	}
	
}
