package ameliorations;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Shape;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;

import geometrieDessin.Vecteur2D;
import outils.Dessinable;
import outils.OutilsImage;
import personnage.Raton;

/**
 * Champ qui attire le raton vers son centre, modifiant sa vitesse
 * @author Justin Gauthier
 * @author Edson François Gertilus
 */
public class Champ implements Dessinable{

	/**Le vecteur de position du champ**/
	private Vecteur2D position;
	/**Le rayon du champ**/
	public final double RAYON = 1;
	/**Le cercle qui delimite le champ**/
	private Ellipse2D.Double champ;
	/**Le nombre de pixels par metre du champ**/
	private double pixelsParMetre =1;
	private double charge =5;
	private double x, y;
	//private Image image = OutilsImage.lireImage("boostVertical.png");
	
	/**Constructeur du champ
	 * 
	 * @param position Le vecteur de la position du champ
	 */
	//Justin Gauthier
	public Champ (Vecteur2D position) {
		this.position = position;
		
		creerLaGeometrie();
	}

	/**Cette méthode a pour but d'obtenir le centre
	 * 
	 * @return le vecteur contenant le centre
	 */
	//Edson François Gertilus
	public Vecteur2D getCentre() {
	    return new Vecteur2D( position.getX() + RAYON, position.getY() + RAYON);
	}
	/**Cette méthode a pour de savoir si il y a une collision ou non
	 * 
	 * @return le boolean contenant la réponse
	 */
	//Edson François Gertilus
	public boolean checkCollisionChamp(Raton raton) {
	    // Retrieve the raton's shape
	    Shape s = raton.getForme();
	    Ellipse2D.Double champForme = new Ellipse2D.Double(position.getX(), position.getY(), RAYON * 2, RAYON * 2);
	    
	    // Use the raton's shape bounds without casting raton to Shape.
	    return champForme.intersects(s.getBounds2D());
	}
	/**Creer la forme qui delimite le champ**/
	//Justin Gauthier
	private void creerLaGeometrie() {
		champ = new Ellipse2D.Double(position.getX(), position.getY(), RAYON*2, RAYON*2);
	}

	/**Dessiner le champ
	 * 
	 * @param g2d le contexte graphique
	 */
	//Justin Gauthier
	@Override
		public void dessiner(Graphics2D g2d) {
		    Graphics2D g2dPrive = (Graphics2D) g2d.create();
		    g2dPrive.scale(pixelsParMetre, pixelsParMetre);
		    
		    // Dessiner plusieurs cercles concentriques pour représenter le champ
		    Color baseColor = Color.MAGENTA;
		    for (int i = 5; i > 0; i--) {
		        float alpha = 0.2f * i;
		        Color fieldColor = new Color(baseColor.getRed()/255f, baseColor.getGreen()/255f, 
		                                    baseColor.getBlue()/255f, alpha);
		        g2dPrive.setColor(fieldColor);
		        double rayon = RAYON * (1 + 0.4 * (5-i));
		        Ellipse2D.Double cercle = new Ellipse2D.Double(
		            position.getX() + RAYON - rayon,
		            position.getY() + RAYON - rayon,
		            rayon * 2,
		            rayon * 2
		        );
		        g2dPrive.fill(cercle);
		    }
		    
		    // Dessiner le champ lui-même
		    g2dPrive.setColor(Color.MAGENTA);
		    g2dPrive.fill(champ);
		    
		    // Indiquer le signe de la charge
		    g2dPrive.setColor(Color.WHITE);
		    String signe = charge > 0 ? "+" : "-";
		    g2dPrive.drawString(signe, (float)(position.getX() + RAYON - 0.1), (float)(position.getY() + RAYON + 0.1));
		}
	
	
	/**Permet d'obtenir la position en x du champ
	 * 
	 * @return la position en x du champ
	 */
	//Justin Gauthier
	public double getX() {
		return x;
	}
	
	
	/**Permet d'obtenir la position en y du champ
	 * 
	 * @return la position en y du champ
	 */
	//Justin Gauthier
	public double getY() {
		return y;
	}
	/**Permet d'obtenir la charge du champ
	 * 
	 * @return la charge du champ
	 */
	//Edson François Gertilus
	public double getCharge() {
	    return charge;
	}
	/**Permet d'obtenir la position en vecteur du champ
	 * 
	 * @return la position du champ
	 */
	//Edson François Gertilus
	public Vecteur2D getPosition() {
        return position;
    }
	/**Vérifie si le champ est en collision avec le personnage selon sa position actuelle
	 * 
	 * @param perso le cerlce qui delimite le personnage
	 * @return si il y a collision ou non
	 */
	//Justin Gauthier

	
	
	/**Permet de déplacer le champ en x
	 * 
	 * @param increment l'increment de deplacement du champ
	 */
	//Justin Gauthier
	public void deplacerChamp(double increment) {
		this.position.setX(this.position.getX()-increment);
		creerLaGeometrie();
	}
	
	/**
	 * Modifie le facteur permettant de passer des metres aux pixels lors du dessin
	 * Ainsi on peut exprimer tout en m,  m/s  et m/s2
	 * @param pixelsParMetre Facteur de mise à l'échelle lors du dessin
	 */
	//Justin Gauthier
	public void setPixelsParMetre(double pixelsParMetre) {
		this.pixelsParMetre = pixelsParMetre;
		
	}
}
