package ameliorations;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import geometrieDessin.Vecteur2D;
import outils.Dessinable;
import outils.OutilsImage;

/**
 * Boost vertical qui fournit un boost de vitesse au raton lors d'une collision
 * @author Justin Gauthier
 */
public class BoostVertical implements Dessinable{

	/**Le vecteur de la position du boost**/
	private Vecteur2D position;
	/**La largeur du boost**/
	private final double LARGEUR = 0.5;
	/**La hauteur du boost**/
	private final double HAUTEUR = 1;
	/**Le rectangle qui délimite le boost**/
	private Rectangle2D.Double boostVertical;
	/**Le nombre de pixels par metre du boost**/
	private double pixelsParMetre =1;
	private Image image = OutilsImage.lireImage("boostVertical.png");
	private Rectangle2D.Double test;

	/**Le constructeur du boost
	 * 
	 * @param position le vecteur de la position du boost
	 */
	//Justin Gauthier
	public BoostVertical(Vecteur2D position) {
		this.position = position;
		creerLaGeometrie();
	}
	
	/**Creer la forme qui delimite le boost**/
	//Justin Gauthier
	private void creerLaGeometrie() {
		boostVertical = new Rectangle2D.Double(position.getX(), position.getY(), LARGEUR, HAUTEUR);
		test = new Rectangle2D.Double((position.getX()), position.getY(),
			    (LARGEUR),(HAUTEUR));
	}

	/**Dessiner le boost
	 * 
	 * @param g2d le contexte graphique
	 */
	//Justin Gauthier
	@Override
	public void dessiner(Graphics2D g2d) {
		Graphics2D g2dPrive = (Graphics2D) g2d.create();
		g2dPrive.scale(pixelsParMetre, pixelsParMetre);
		g2dPrive.setColor(Color.CYAN);
		g2dPrive.fill(boostVertical);
		g2dPrive.scale((1/pixelsParMetre), (1/pixelsParMetre));
		g2dPrive.drawImage(image, (int)(position.getX()*pixelsParMetre)-5, (int)(position.getY()*pixelsParMetre)-5, (int)(LARGEUR*pixelsParMetre)+10, (int)(HAUTEUR*pixelsParMetre)+10, null);
	}
	
	/**Permet d'obtenir la position en x du boost
	 * 
	 * @return la position en x du boost
	 */
	//Justin Gauthier
	public double getX() {
		return position.getX();
	}
	
	/**Permet d'obtenir la position en y du boost
	 * 
	 * @return la position en y du boost
	 */
	//Justin Gauthier
	public double getY() {
		return position.getY();
	}
	
	/**Vérifie si le boost est en collision avec le personnage selon sa position actuelle
	 * 
	 * @param perso le cercle qui delimite le personnage
	 * @return si il y a collision ou non
	 */
	//Justin Gauthier
	public boolean checkCollisionVertical(Ellipse2D.Double perso) {
		Area airePerso = new Area(perso);
		Rectangle2D.Double boost = new Rectangle2D.Double(this.getX(), this.getY(), LARGEUR, HAUTEUR);
		Area aireBoost = new Area(boost);
		airePerso.intersect(aireBoost);
		if(airePerso.isEmpty()) {
			return false;
		}else {
			return true;
		}
	}
	
	/**Permet de déplacer le boost en x
	 * 
	 * @param increment l'increment de deplacement du boost
	 */
	//Justin Gauthier
	public void deplacerBoost(double increment) {
		this.position.setX(this.position.getX()-increment);
		creerLaGeometrie();
	}
	
	/**
	 * Modifie le facteur permettant de passer des metres aux pixels lors du dessin
	 * Ainsi on peut exprimer tout en m,  m/s  et m/s2
	 * @param pixelsParMetre Facteur de mise à l'échelle lors du dessin
	 */
	//Justin Gauthier
	public void setPixelsParMetre(double pixelsParMetre) {
		this.pixelsParMetre = pixelsParMetre;
		
	}
	
	
}
