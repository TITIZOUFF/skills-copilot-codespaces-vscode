package obstacles;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.geom.Ellipse2D.Double;

import geometrieDessin.Vecteur2D;
import outils.Dessinable;
import outils.OutilsImage;

	/**
	 * Classe représentant un sapin sous forme de triangle.
	 * @author Stanislav Kouznetsov
	 * @author Justin Gauthier
	 */
	public class Sapin implements Dessinable {

	    /** Position du sapin dans le plan. */
	    private Vecteur2D position;

	    /** Position en Y fixe du sapin. */
	    private final double POSITION_Y = 2.5;

	    /** Largeur du sapin. */
	    private final double LONGUEUR_SAPIN = 2;

	    /** Hauteur du sapin. */
	    private double HAUTEUR_SAPIN = 3;

	    /** Représentation géométrique du sapin sous forme de triangle. */
	    private Path2D.Double triangleSapin;

	    /** Facteur d'échelle pour la conversion des unités en pixels. */
	    private double pixelsParMetre = 1;
	    
	    private Image image = OutilsImage.lireImage("arbre.png");

	    /**
	     * Constructeur de la classe Sapin.
	     * 
	     * @param position La position du sapin.
	     */
	    //Stanislav Kouznetsov
	    public Sapin(Vecteur2D position) {
	        this.position = position;
	        creerLaGeometrie();
	    }

	    /**
	     * Crée la géométrie du sapin sous forme d'un triangle.
	     */
	  //Stanislav Kouznetsov
	    private void creerLaGeometrie() {
	        triangleSapin = new Path2D.Double();
	        triangleSapin.moveTo(position.getX(), getPOSITION_Y() + HAUTEUR_SAPIN);
	        triangleSapin.lineTo(position.getX() + LONGUEUR_SAPIN, getPOSITION_Y() + HAUTEUR_SAPIN);
	        triangleSapin.lineTo(position.getX() + LONGUEUR_SAPIN / 2, getPOSITION_Y());
	        triangleSapin.closePath();
	    }

	    /**
	     * Dessine le sapin sur la scène.
	     * Cette méthode garde le contexte graphique intact pour éviter d'affecter d'autres objets.
	     * 
	     * @param g2d L'objet Graphics2D utilisé pour le dessin.
	     */
	  //Stanislav Kouznetsov
	    public void dessiner(Graphics2D g2d) {
	        Graphics2D g2dPrive = (Graphics2D) g2d.create();
	        g2dPrive.scale(pixelsParMetre, pixelsParMetre);
	        g2dPrive.setColor(Color.GREEN);
	        g2dPrive.fill(triangleSapin);
	        //g2dPrive.drawImage(image, (int)position.getX(), (int)(position.getY()+HAUTEUR_SAPIN), (int)LONGUEUR_SAPIN, (int)HAUTEUR_SAPIN ,null);
	    }

	    /**
	     * Retourne la coordonnée en X du sapin.
	     * 
	     * @return La coordonnée en X du sapin.
	     */
	  //Stanislav Kouznetsov
	    public double getX() {
	        return position.getX();
	    }

	    /**
	     * Modifie la coordonnée en X du sapin.
	     * La géométrie est recréée après la modification.
	     * 
	     * @param xPosition La nouvelle coordonnée en X du sapin.
	     */
	  //Stanislav Kouznetsov
	    public void setX(double xPosition) {
	        this.position.setX(xPosition);
	        creerLaGeometrie();
	    }

	    /**
	     * Retourne la coordonnée en Y du sapin.
	     * 
	     * @return La coordonnée en Y du sapin.
	     */
	  //Stanislav Kouznetsov
	    public double getY() {
	        return getPOSITION_Y();
	    }

	    /**
	     * Retourne la largeur du sapin.
	     * 
	     * @return La largeur du sapin.
	     */
	  //Stanislav Kouznetsov
	    public double getLongueurSapin() {
	        return LONGUEUR_SAPIN;
	    }

	    /**
	     * Retourne la hauteur du sapin.
	     * 
	     * @return La hauteur du sapin.
	     */
	  //Stanislav Kouznetsov
	    public double getHauteurSapin() {
	        return HAUTEUR_SAPIN;
	    }
	
	
	/**Permet de déplacer le sapin en x
	 * 
	 * @param increment l'increment de deplacement du sapin
	 */
	//Justin Gauthier
	public void deplacerSapin(double increment) {
		this.position.setX(this.position.getX()-increment);
		creerLaGeometrie();
	}
	
	/**
	 * Permet de verifier la collision entre le sapin et le raton
	 * @param perso le cercle qui delimite le raton
	 * @return si il y a une collision ou non
	 */
	 public boolean checkCollisionSapin(Ellipse2D.Double perso) {
	        Area airePerso = new Area(perso);
	        Area aireSapin = new Area(triangleSapin);
	        airePerso.intersect(aireSapin);
	        return !airePerso.isEmpty();
	    }
    /**
	 * Modifie le facteur permettant de passer des metres aux pixels lors du dessin
	 * Ainsi on peut exprimer tout en m,  m/s  et m/s2
	 * @param pixelsParMetre Facteur de mise à l'échelle lors du dessin
	 */
	//Justin Gauthier
	public void setPixelsParMetre(double pixelsParMetre) {
		this.pixelsParMetre = pixelsParMetre;
		
	}

	public double getPOSITION_Y() {
		return POSITION_Y;
	}
	// Nouvelle méthode dans la classe Sapin
	}
