package obstacles;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;

import geometrieDessin.Vecteur2D;
import outils.Dessinable;
import outils.OutilsImage;

/**
 * Classe représentant une roche sous forme d'un arc de cercle.
 * 
 * @author Stanislav Kouznetsov
 * @author Justin Gauthier
 */

public class Roche implements Dessinable {

	/** Position de la roche dans le plan. */
	private Vecteur2D position;

	/** Position en Y fixe de la roche. */
	private final double POSITION_Y = 3.97;

	/** Longueur de la roche. */
	private final double LONGUEUR_ROCHE = 3;

	/** Hauteur de la roche. */
	private double HAUTEUR_ROCHE = 3;

	/** Représentation géométrique de la roche sous forme d'un arc. */
	private Arc2D.Double cercleRoche;

	/** Facteur d'échelle pour la conversion des unités en pixels. */
	private double pixelsParMetre = 1;

	private Image image = OutilsImage.lireImage("roche.png");

	boolean contient;
	private boolean selectionne;

	/**
	 * Constructeur de la classe Roche.
	 * 
	 * @param position La position de la roche.
	 */
	// Stanislav Kouznetsov
	public Roche(Vecteur2D position) {
		this.position = position;
		this.selectionne = false;
		creerLaGeometrie();
	}

	/**
	 * Crée la géométrie de la roche sous forme d'un arc de cercle.
	 */
	// Stanislav Kouznetsov
	private void creerLaGeometrie() {
		cercleRoche = new Arc2D.Double(position.getX(), position.getY(), LONGUEUR_ROCHE, HAUTEUR_ROCHE, 0, 180, Arc2D.CHORD);
	}

	/**
	 * Dessine la roche sur la scène.
	 * 
	 * @param g2d L'objet Graphics2D utilisé pour le dessin.
	 */
	// Stanislav Kouznetsov
	public void dessiner(Graphics2D g2d) {
		Graphics2D g2dPrive = (Graphics2D) g2d.create();
		g2dPrive.scale(pixelsParMetre, pixelsParMetre);
		g2dPrive.setColor(Color.BLUE);
		g2dPrive.fill(cercleRoche);
	}

	/**
	 * Retourne la coordonnée en X du coin supérieur gauche de la roche.
	 * 
	 * @return La coordonnée en X de la roche.
	 */
	// Stanislav Kouznetsov
	public double getX() {
		return position.getX();
	}

	/**
	 * Modifie la coordonnée en X de la roche. La géométrie est recréée après la
	 * modification.
	 * 
	 * @param xPosition La nouvelle coordonnée en X de la roche.
	 */
	// Stanislav Kouznetsov
	public void setX(double xPosition) {
		position.setX(xPosition);
		creerLaGeometrie();
	}
	public void setY(double y) {
	    this.position.setY(y);
	}
	/**
	 * Retourne la coordonnée en Y de la roche.
	 * 
	 * @return La coordonnée en Y de la roche.
	 */
	// Stanislav Kouznetsov
	public double getY() {
		return POSITION_Y;
	}

	/**
	 * Retourne la longueur de la roche.
	 * 
	 * @return La longueur de la roche.
	 */
	// Stanislav Kouznetsov
	public double getLongueurRoche() {
		return LONGUEUR_ROCHE;
	}

	/**
	 * Retourne la hauteur de la roche.
	 * 
	 * @return La hauteur de la roche.
	 */
	// Stanislav Kouznetsov
	public double getHauteurRoche() {
		return HAUTEUR_ROCHE;
	}

	/**
	 * Permet de déplacer la roche en x
	 * 
	 * @param increment l'increment de deplacement de la roche
	 */
	// Justin Gauthier
	public void deplacerRoche(double increment) {
		this.position.setX(this.position.getX() - increment);
		creerLaGeometrie();
	}

	/**
	 * Permet de verifier la collision entre la roche et le raton
	 * 
	 * @param perso le cercle qui delimite le raton
	 * @return si il y a une collision ou non
	 */
	// Justin Gauthier
	public boolean checkCollisionRoche(Ellipse2D.Double perso) {
		Area airePerso = new Area(perso);
		Area aireRoche = new Area(cercleRoche);
		airePerso.intersect(aireRoche);
		return !airePerso.isEmpty();
	}

	/**
	 * Modifie le facteur permettant de passer des metres aux pixels lors du dessin
	 * Ainsi on peut exprimer tout en m, m/s et m/s2
	 * 
	 * @param pixelsParMetre Facteur de mise à l'échelle lors du dessin
	 */
	// Justin Gauthier
	public void setPixelsParMetre(double pixelsParMetre) {
		this.pixelsParMetre = pixelsParMetre;

	}

	public boolean contient(double x, double y) {
		contient = false;
		AffineTransform mat = new AffineTransform();
		Shape rocheContient = mat.createTransformedShape(new Arc2D.Double(position.getX() * pixelsParMetre,
				position.getY() * pixelsParMetre, LONGUEUR_ROCHE * pixelsParMetre, HAUTEUR_ROCHE * pixelsParMetre, 0, 180 , Arc2D.CHORD));

		return rocheContient.contains(x, y);

	}
	
	public void setSelectionne(boolean selectionne) {
		this.selectionne = selectionne;
	}
	
	public boolean getSelectionne() {
		return this.selectionne;
	}
	
	/**
	 * Retourne la position de la roche sous forme d'un vecteur 2D.
	 *
	 * @return La position de la roche.
	 */
	public Vecteur2D setPosition() {
	    return position;
	}
}
