package obstacles;


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import geometrieDessin.Vecteur2D;
import outils.Dessinable;
import outils.OutilsImage;

/**
 * Classe représentant une voiture sous forme de rectangle.
 * 
 * @author Stanislav Kouznetsov
 * @author Justin Gauthier
 */
public class Voiture implements Dessinable {

    /** Position de la voiture dans le plan. */
    private Vecteur2D position;

    /** Position en Y fixe de la voiture. */
    private double POSITION_Y = 4.17;

    /** Longueur de la voiture. */
    private double LONGUEUR_VOITURE = 3.5;

    /** Hauteur de la voiture. */
    private double HAUTEUR_VOITURE = 1.3;

    /** Représentation géométrique de la voiture sous forme de rectangle. */
    private Rectangle2D.Double rectangleVoiture;

    /** Facteur d'échelle pour la conversion des unités en pixels. */
    private double pixelsParMetre = 1;
    
    private Image image = OutilsImage.lireImage("voiture.png");

    /**
     * Constructeur de la classe Voiture.
     * 
     * @param position La position de la voiture.
     */
    //Stanislav Kouznetsov
    public Voiture(Vecteur2D position) {
        this.position = position;
        creerLaGeometrie();
    }

    /**
     * Crée la géométrie de la voiture sous forme d'un rectangle.
     */
  //Stanislav Kouznetsov
    private void creerLaGeometrie() {
        rectangleVoiture = new Rectangle2D.Double(position.getX(), POSITION_Y, LONGUEUR_VOITURE, HAUTEUR_VOITURE);
    }

    /**
     * Dessine la voiture sur la scène.
     * 
     * @param g2d L'objet Graphics2D utilisé pour le dessin.
     */
  //Stanislav Kouznetsov
    public void dessiner(Graphics2D g2d) {
        Graphics2D g2dPrive = (Graphics2D) g2d.create();
        g2dPrive.scale(pixelsParMetre, pixelsParMetre);
        g2dPrive.setColor(Color.ORANGE);
        g2dPrive.fill(rectangleVoiture);
    }

    /**
     * Retourne la coordonnée en X de la voiture.
     * 
     * @return La coordonnée en X de la voiture.
     */
  //Stanislav Kouznetsov
    public double getX() {
        return this.position.getX();
    }

    /**
     * Modifie la coordonnée en X de la voiture.
     * La géométrie est recréée après la modification.
     * 
     * @param xPosition La nouvelle coordonnée en X de la voiture.
     */
  //Stanislav Kouznetsov
    public void setX(double xPosition) {
        this.position.setX(xPosition);
        creerLaGeometrie();
    }

    /**
     * Retourne la coordonnée en Y de la voiture.
     * 
     * @return La coordonnée en Y de la voiture.
     */
  //Stanislav Kouznetsov
    public double getY() {
        return POSITION_Y;
    }

    /**
     * Retourne la longueur de la voiture.
     * 
     * @return La longueur de la voiture.
     */
  //Stanislav Kouznetsov
    public double getLongueurVoiture() {
        return LONGUEUR_VOITURE;
    }

    /**
     * Retourne la hauteur de la voiture.
     * 
     * @return La hauteur de la voiture.
     */
  //Stanislav Kouznetsov
    public double getHauteurVoiture() {
        return HAUTEUR_VOITURE;
    }
	
	/**Permet de déplacer la voiture en x
	 * 
	 * @param increment l'increment de deplacement de la voiture
	 */
	//Justin Gauthier
	public void deplacerVoiture(double increment) {
		this.position.setX(this.position.getX()-increment);
		creerLaGeometrie();
	}
	
	/**
	 * Permet de verifier la collision entre la voiture et le raton
	 * @param perso le cercle qui delimite le raton
	 * @return si il y a une collision ou non
	 */
	//Justin Gauthier
	public boolean checkCollisionVoiture(Ellipse2D.Double perso) {
		Area areaPerso = new Area(perso);
	    Area areaVoiture = new Area(rectangleVoiture);
	    areaPerso.intersect(areaVoiture);
	    return !areaPerso.isEmpty();
	}
	  
	/**
	 * Modifie le facteur permettant de passer des metres aux pixels lors du dessin
	 * Ainsi on peut exprimer tout en m,  m/s  et m/s2
	 * @param pixelsParMetre Facteur de mise à l'échelle lors du dessin
	 */
	//Justin Gauthier
	public void setPixelsParMetre(double pixelsParMetre) {
		this.pixelsParMetre = pixelsParMetre;
		
	}
	  
}

	
