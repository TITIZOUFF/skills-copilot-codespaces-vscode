package obstacles;



import java.awt.Color;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import geometrieDessin.Vecteur2D;
import outils.Dessinable;
import outils.OutilsImage;

/**
 * Classe représentant un bâtiment sous forme d'un rectangle.
 * 
 * @author Stanislav Kouznetsov
 * @author Justin Gauthier
 */

public class Batiment implements Dessinable {
	
	 /** Position du bâtiment dans le plan. */
    private Vecteur2D position;

    /** Position en Y fixe du bâtiment. */
    private final double POSITION_Y = 2.5;

    /** Longueur du bâtiment. */
    private final double LONGUEUR_BATIMENT = 1.5;

    /** Hauteur du bâtiment. */
    private final double HAUTEUR_BATIMENT = 2.97;

    /** Représentation géométrique du bâtiment sous forme de rectangle. */
    private Rectangle2D.Double rectangleBatiment;

    /** Facteur d'échelle pour la conversion des unités en pixels. */
    private double pixelsParMetre = 1;
    
    private Image image = OutilsImage.lireImage("batiment.png");
	
    
    /**
     * Constructeur de la classe Batiment.
     * 
     * @param position La position du bâtiment.
     */
    //Stanislav Kouznetsov
	public Batiment(Vecteur2D position) {
		this.position = position;
		creerLaGeometrie();
	} 
	
	 /**
     * Crée la géométrie du bâtiment sous forme d'un rectangle.
     */
    //Stanislav Kouznetsov
	private void creerLaGeometrie() {
		rectangleBatiment = new Rectangle2D.Double(position.getX(), POSITION_Y,LONGUEUR_BATIMENT, HAUTEUR_BATIMENT);
		
	}
	
	/**
     * Dessine le bâtiment sur la scène.
     * 
     * @param g2d L'objet Graphics2D utilisé pour le dessin.
     */
    //Stanislav Kouznetsov
	public void dessiner(Graphics2D g2d) {
		Graphics2D g2dPrive = (Graphics2D) g2d.create();
		g2dPrive.scale(pixelsParMetre, pixelsParMetre);
		g2dPrive.setColor(Color.RED);
		g2dPrive.fill(rectangleBatiment);
		
	}
	/**
	 * Retourner la coordonnée en X du coin supérieur-gauche du rectangle qui entoure le bâtiment
	 * @return La corodonnée en X du coin supérieur-gauche du rectangle qui entoure le bâtiment
	 */
    //Stanislav Kouznetsov
	public double getX() {
		return position.getX();
	}
	/**
	 * Modifier la coordonnée en X du coin supérieur-gauche du rectangle qui englobe le bâtiment
	 *  La géométrie sera recréée suite à ce changement.
	 * @param x La nouvelle coordonnée en X du coin supérieur-gauche du rectangle qui englobe le bâtiment
	 */
    //Stanislav Kouznetsov
	public void setX(double xPosition) {
		this.position.setX(xPosition);
		creerLaGeometrie();
	}
	/**
	 * Retourne la coordonnée en Y du coin supérieur-gauche du rectangle qui englobe le bâtiment
	 * @return La coordonnée en Y du coin supérieur-gauche du rectangle qui englobe le bâtiment
	 */
    //Stanislav Kouznetsov
	public double getY() {
		return position.getY();
	}
	/**
	 * Retourne la largeur du bâtiment
	 * @return La largeur du bâtiment
	 */
    //Stanislav Kouznetsov
	public double getLongueurBatiment() {
		return LONGUEUR_BATIMENT;
	}
	
	/**
	 * Retourner la hauteur du bâtiment
	 * @return La hauteur du bâtiment
	 */
    //Stanislav Kouznetsov
	public double getHauteurBatiment() {
		return HAUTEUR_BATIMENT;
	}
	
	
	/**Permet de déplacer le batiment en x
	 * 
	 * @param increment l'increment de deplacement du batiment
	 */
	//Justin Gauthier
	public void deplacerBatiment(double increment) {
		this.position.setX(this.position.getX()-increment);
		creerLaGeometrie();
	}
	/**
	 * Permet de verifier la collision entre le batiment et le raton
	 * @param perso le cercle qui delimite le raton
	 * @return si il y a une collision ou non
	 */
	//Justin Gauthier
    public boolean checkCollisionBatiment(Ellipse2D.Double perso) {
        Area airePerso = new Area(perso);
        Area aireBatiment = new Area(rectangleBatiment);
        airePerso.intersect(aireBatiment);
        return !airePerso.isEmpty();
    }
    
    /**
	 * Modifie le facteur permettant de passer des metres aux pixels lors du dessin
	 * Ainsi on peut exprimer tout en m,  m/s  et m/s2
	 * @param pixelsParMetre Facteur de mise à l'échelle lors du dessin
	 */
	//Justin Gauthier
	public void setPixelsParMetre(double pixelsParMetre) {
		this.pixelsParMetre = pixelsParMetre;
		
	}

}
	
	


