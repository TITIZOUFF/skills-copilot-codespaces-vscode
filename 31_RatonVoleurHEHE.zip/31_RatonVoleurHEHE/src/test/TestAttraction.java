// Exemple de classe de test pour vérifier l'attraction
package test;

import geometrieDessin.Vecteur2D;
import physique.MoteurPhysique;
import ameliorations.Champ;
import personnage.Raton;

public class TestAttraction {
    public static void main(String[] args) throws Exception {
        // Créer une position initiale pour le raton
        Vecteur2D posRaton = new Vecteur2D(0, 0);
        // Créer un raton avec un rayon de 0.5 m (donc largeur = 1.0 m)
        Raton raton = new Raton(posRaton, 0.5);
        
        // Pour ce test, on positionne le champ à 2 mètres à droite et 2 mètres en bas du raton
        Vecteur2D posChamp = new Vecteur2D(2, 2);
        // On suppose que la classe Champ possède un constructeur avec sa position et une charge
        // (Adapte la signature à ta classe Champ)
        double chargeChamp = 500; // valeur d'exemple pour la charge du champ
        Champ champ = new Champ(posChamp);
        
        // On définit des charges pour le raton et le champ pour rendre l'effet visible
        // Par exemple, on peut rendre la charge du raton élevée pour "abuser" de l'attraction
        double chargeRaton = 1000;
        // Supposons que Raton a une méthode setCharge (ajoute-la si nécessaire)
        // Sinon, adapte la valeur retournée par getCharge() dans ton code
        // (Ici, nous simulons simplement qu'elles sont définies dans le constructeur)
        // raton.setCharge(chargeRaton); // à adapter selon ton implémentation

        // Simuler la détection de collision et appliquer la force
        System.out.println("Avant attraction, vitesse du raton : " + raton.getVitesse());
        // Appel à gererCollisionChamp qui calcule et applique la force
        raton.gererCollisionChamp(champ);
        System.out.println("Après attraction, vitesse du raton : " + raton.getVitesse());
    }
}
