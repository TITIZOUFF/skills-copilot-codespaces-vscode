package composantdessin;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import java.util.ArrayList;
import java.util.List;


import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JSlider;

import ameliorations.BoostHorizontal;
import ameliorations.BoostVertical;
import ameliorations.Champ;
import ameliorations.Recharge;
import geometrieDessin.BarreNewtons;


	
import geometrieDessin.FlecheVectorielle;
import geometrieDessin.Vecteur2D;
import niveau.Niveau;
import obstacles.Batiment;
import obstacles.Roche;
import obstacles.Sapin;
import obstacles.Voiture;
import outils.OutilsImage;
import personnage.Raton;
import physique.GestionnaireEvenementsPhysique;

import personnage.Raton;

import physique.GestionnaireEvenementsPhysique;

import physique.MoteurPhysique;


/**
 * Classe principale gérant l'affichage et la simulation du jeu.
 * 
 * @author Stanislav Kouznetsov
 * @author Darwinsh Saint-Jean
 * @author Justin Gauthier
 * @author Edson François Gertilus
 */
public class JeuPrincipal extends JPanel implements Runnable {

	private static final long serialVersionUID = 1L;
	
	private List<Champ> champs = new ArrayList<>();

	/** Largeur du composant en mètres. */
	private double largeurDuComposantEnMetres = 10;

	/** Hauteur du composant en mètres. */
	private double hauteurDuComposantEnMetres;

	/** Nombre de pixels par mètre pour l'affichage. */
	private double pixelsParMetre;

	/** Indique si l'animation est en cours. */
	private boolean enCoursDAnimation = false;

	/** Représentation du sol dans le jeu. */
	private Rectangle2D.Double sol;

	/** Objet représentant le raton. */
	private Raton raton;

	/** Coordonnée verticale du raton. */
	private double yRaton = 5.11;

	/** Temps total écoulé dans la simulation. */
	private double tempsTotalEcoule;

	/** Pas de temps pour la simulation physique. */
	private double deltaT = 0.009;

	/** Temps de pause entre chaque itération d'animation (en millisecondes). */
	private int tempsDePause = 36;

	/** Masse du raton en kg. */
	private double masseRaton = 1;

	/** Force gravitationnelle appliquée au raton. */
	private Vecteur2D forceGrav;

	/** Vitesse du raton. */
	private Vecteur2D vitesse;

	/** Accélération du raton. */
	private Vecteur2D acceleration;

	/** Position du raton. */
	private Vecteur2D position;

	/** Force de lancement du raton. */
	private Vecteur2D fLancement;

	/** Indique si un clic peut être effectué pour commencer l'animation. */
	private boolean peutCliquer = true;

	/** Curseur d'orientation associé au tir. */
	private JSlider orientationAssocie;

	/** Bouton permettant de passer à l'étape suivante. */
	private JButton suivantAssocie; 

	/** Curseur de force associé au tir. */
	private JSlider forceAssocie;

	/** Bouton permettant de valider le tir. */
	private JButton termineAssocie;
	
	/** Objets représentant les différents niveaux. */
	private Niveau niveau1, niveau2, niveau3;

	/** Niveau actuellement sélectionné. */
	private int niveau;

	/** Niveau actuellement choisi par l'utilisateur. */
	public static int niveauSelectionne = 1;

	/** Hauteur des niveaux en pixels. */
	private int hauteurNiveau = 1000;

	/** Longueur des niveaux en pixels. */
	private int longeurNiveau;
	
	private int longeurNiveau2 = 10000;
	
	private int longeurNiveau3 = 15000;

	/** Vecteur représentant l'orientation de la force appliquée. */
	private FlecheVectorielle orientation;

	/** Vecteur représentant l'angle de rotation. */
	private Vecteur2D angleRotation = new Vecteur2D(1, 0);

	/** Facteur de redimensionnement de la flèche de force. */
	private double facteurRedim = 0.5;

	/** Score du joueur. */
	private int score = 0;
	
    /** Coordonnées en x de l'image d'arrière-plan loin, coin gauche*/
    private int coinGaucheImageXLoin = 0;
    /** Coordonnées en x de l'image d'arrière-plan proche, coin gauche*/
    private int coinGaucheImageXProche = 0;
    /** Coordonnées en y de l'image d'arrière-plan, coin gauche */
    private int coinGaucheImageY = 0;
    /** Coordonnées en x de l'image d'arrière-plan loin, coin droit*/
    private int coinDroitImageXLoin = 1224;
    /** Coordonnées en x de l'image d'arrière-plan proche, coin droit*/
    private int coinDroitImageXProche = 1224;
    /** Coordonnées en y de l'image d'arrière-plan, coin droit*/
    private int coinDroitImageY = 688;
    
    private int coinGaucheDessinLoin = 0;
    private int coinDroitDessinLoin = 954;
    private int coinGaucheDessinProche = 0;
    private int coinDroitDessinProche = 954;
    private int moitieBackgroundProche = 1224;
    private int moitieBackgroundLoin = 1224;
    private int moitieBackgroundProcheInit = 1224;
    private int moitieBackgroundLoinInit = 1224;

	/** Valeur de l'angle de lancement. */
	private double orientationForceLancement;

	/** Valeur de la force de lancement. */
	private double forceForceLancement;

	/** Position initiale du raton. */
	private Vecteur2D posInitRaton = new Vecteur2D(4.5, 4.95);

	/** Vecteur nul utilisé pour réinitialiser certaines valeurs. */
	private Vecteur2D vecZero = new Vecteur2D(0, 0);

	/** Indique si le message "Commencer" doit être affiché. */
	private boolean afficherLabelCommencer = true;
	
	/** Indique si c'est la première itération du jeu. */
	private boolean premiereFois = true;

	/** Indique si c'est la première itération de dessin. */
	private boolean premiereFoisDessin = true;

	/** Valeur d'incrémentation du déplacement horizontal. */
	private double incrementDeplacementX;

	/** Dernière progression enregistrée. */
	private int progressionPrecedente = -1;

	/** Dernier score enregistré. */
	private int scorePrecedent = -1;

	/** Compteur utilisé pour gérer les étapes d'animation. */
	private int conteurAnimation = 0;

	/** Barre représentant la force exercée sur le raton. */
	private BarreNewtons barreNewtons;

    /** Force appliquée par la barre de Newtons. */
    private final Vecteur2D FORCE_BARRE_NEWTONS = new Vecteur2D(5, -10);
    
    private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    
    /** Coordonné X où la flèche est placée. */
    private double placementX =  4.5;
    
    /** Coordonné Y où la flèche est placée. */
    private double placementY = 5.01;
    
    /** La longueur de la tête de la flèche. */
    private double longueurTete = 0.157;
    
    /** L'angle de la tête de la flèche. */
    private int angleTete = 60;
    
    /** La distance choisie entre la flèche et le raton. */
    private double distanceRatonFleche = 0.5;
    
    /** Représente une valeur nulle. */
    private int valeurZero = 0;
    
    /** La valeur initiale du coin droit de l'image en X. */
    private int coinXDroitInit = 1224;
    
    /** La valeur initiale du coin droit de l'image en Y. */
    private int coinYDroitInit = 688;
    
    /** L'épaisseur de base de la flèche. */
    private int strokeBase = 7;
    
    /** La coordonnée en X du vecteur de postion. */
    private double posX = 4.5;
    
    /** La coordonnée en Y du vecteur de postion. */
    private double posY = 4.95;
    
    /** La longueur de la barre des Newtons. */
    private double longueurBarre = largeurDuComposantEnMetres-1;
    
    /** La position en X de la barre des Newtons. */
    private double xBarre = 0.5;
    
    /** La position en Y de la barre des Newtons. */
    private double yBarre = 0.5;
    
    /** Le rayon du raton. */
    private double rayonRaton = 0.17;
    
    /** La valeur de base du slider de force. */
    private int forceInit = 100;
    
    /** La valeur de base du slider d'orientation. */
    private int orientationInit = 45;

    /** La valeur pour avoir la barre progression */
    private double divProgres = 1000;
    
    /** La valeur local pour prendre la progression et mettre dans dessinerEchelle*/
    private int progressionActuelle = 0;
    
    /** La valeur pour savoir quand le niveau va s'arrêter*/
    private int nivComplet = 100;
    
    /** La valeur de la graduation de l'échelle*/
    private int echelleGrad = 10;
   
    
    private double positionX = 0;

    private Image backgroundLoin;
    
	private Image backgroundProche;

    
    
    private final GestionnaireEvenementsPhysique gestionnaire;
    
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        pcs.addPropertyChangeListener(listener);
    }

	/**
	 * Creer le paneau.
	 */
	public JeuPrincipal() {
		tailleNiveau();
		creerNiveaux();
		creerImages();
		addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				gererClavierPressed(e);
			}
		});
		setBackground(new Color(255, 255, 255));
		setLayout(null);
		gestionnaire = new GestionnaireEvenementsPhysique(new MoteurPhysique());

		addComponentListener(new java.awt.event.ComponentAdapter() {
			@Override
			public void componentResized(java.awt.event.ComponentEvent evt) {
				creerObjetsDessinables();
				repaint();
			}
		});
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if(e.getClickCount() == 1 & !enCoursDAnimation & peutCliquer ) {
					rendreSOrientationVisible();
					rendreBoutonSuivantVisible();
					afficherLabelCommencer = false;
					peutCliquer = false;

					repaint();

				} 

			}
		});
		;

	}

	/**
	 * creer les objets dessinables
	 */
	//Darwinsh Saint-Jean
	private void creerObjetsDessinables() {
		position = new Vecteur2D(posX, posY);
	    vitesse = new Vecteur2D(valeurZero, valeurZero);
	    acceleration = new Vecteur2D(valeurZero, valeurZero);
	    creerNiveaux();
	    creerObstacles();
	    barreNewtons = new BarreNewtons(xBarre, yBarre, longueurBarre);
	    raton = new Raton(new Vecteur2D(posX, yRaton), rayonRaton);
		raton.setMasse(masseRaton);
	}

	
	/**
	 * Dessine les éléments de la scène du jeu
	 */
	//Justin Gauthier
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g; 
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON );                     
		Stroke originalStroke = g2d.getStroke();

		//pixelsParMetre
		if(premiereFoisDessin) {
			pixelsParMetre = getWidth()/largeurDuComposantEnMetres;
			hauteurDuComposantEnMetres = getHeight()/pixelsParMetre;
			creerObjetsDessinables();
			premiereFoisDessin = false;
		}


		creerFleche();

		//dessinerSol
		sol = new Rectangle2D.Double(0, hauteurDuComposantEnMetres-0.21, largeurDuComposantEnMetres, 0.21);
		g2d.setColor(Color.green.darker());
		g2d.scale(pixelsParMetre, pixelsParMetre);
		g2d.fill(sol);
		g2d.scale(1/pixelsParMetre, 1/pixelsParMetre);
		g2d.setColor(Color.gray);
		
		//images
		dessinerBackground(g2d);
		if(afficherLabelCommencer) {
			g2d.drawImage(OutilsImage.lireImage("messageCommencer.png"), 100, 200, null);
		}

		//Dessiner barre de Newtons

		barreNewtons.setPixelsParMetre(pixelsParMetre);
		barreNewtons.dessiner(g2d);

		//dessinerRaton
		raton.setPixelsParMetre(pixelsParMetre);
		raton.dessiner(g2d);
		
		if(orientationAssocie.isEnabled()) {
			dessinFleche(g2d);
		}


		if (forceAssocie.isEnabled()) {
			rendreBoutonTermineVisible();
			orientation.redimensionneCorps(forceAssocie.getValue()/25.0);
			dessinFleche(g2d);


		}
		
		niveau2.setPixelsParMetre(pixelsParMetre);
		niveau2.dessinerObstacles(g2d);

		niveau1.setPixelsParMetre(pixelsParMetre);
		niveau1.dessinerObstacles(g2d);
		
		niveau3.setPixelsParMetre(pixelsParMetre);
		niveau3.dessinerObstacles(g2d);


		dessinerEchelle(g2d);
		g2d.setStroke(originalStroke);

	}
	
	/** Exécute l'animation principale du jeu.
	 * 	Met à jour la position du raton et gère les forces appliquées
	 */
	//Darwinsh Saint-Jean
	@Override
	public void run() {
		while (enCoursDAnimation) {

			if (conteurAnimation == valeurZero) {
				fLancement = creerForceLancement(orientationForceLancement, forceForceLancement);
				forceGrav = MoteurPhysique.calculForceGrav(masseRaton);
				raton.setSommeDesForces(fLancement.additionne(forceGrav));
				
				appliquerForces();       
				repaint();
			} else {
				// Réinitialiser à la gravité à chaque itération
				raton.setSommeDesForces(MoteurPhysique.calculForceGrav(masseRaton));
			}
            raton.updatePosition(deltaT);
            
	        try {
				calculerUneIterationPhysique(deltaT);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			repaint();
			conteurAnimation++;
			try {
				Thread.sleep(tempsDePause);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("Le thread est mort...!");
	}

	/** Créer la flèche qui indique l'orientation de lancement
	 * 	La rotation de la flèche est calculée en fonction de l'angle donné par le slider d'orientation
	 */
	//Darwinsh Saint-Jean
	private void creerFleche() {
		double angle = -orientationAssocie.getValue();
		 

		double centreX = (raton.getX() + raton.getRayon() + placementX) + distanceRatonFleche * Math.cos(Math.toRadians(angle));
		double centreY = (raton.getY() + raton.getRayon() +	placementY)	+ distanceRatonFleche * Math.sin(Math.toRadians(angle));

		angleRotation = new Vecteur2D(Math.cos(Math.toRadians(angle)), Math.sin(Math.toRadians(angle)));
		orientation = new FlecheVectorielle(centreX, centreY, angleRotation);

		orientation.setPixelsParMetre(pixelsParMetre);
		orientation.redimensionneCorps(facteurRedim);
		orientation.setLongueurTraitDeTete(longueurTete);
		orientation.setAngleTete(angleTete);
	}


	/** Démarre l'animation si elle n'est pas déjà en cours.
	 * Créer un thread qui exécute la méthode run().
	 */
	//Darwinsh Saint-Jean
	public void demarrer() {
		if (!enCoursDAnimation) {
			enCoursDAnimation = true;
			Thread processusAnimation = new Thread(this);
			processusAnimation.start();
		}
	}

	/** Calcule la prochaine image de l'animation si elle n'est pas en cours.
	 * Met à jour la physique et teste les collisions
	 */
	//Darwinsh Saint-jean
	public void prochaineImage() throws Exception {
		if(!enCoursDAnimation) {
			//System.out.println("On avance de " + deltaT + " secondes");
			calculerUneIterationPhysique(deltaT);
			testerCollisionsEtModifierVitesses();
			repaint();
		}
	}

	/** Met fin à l'animation en cours
	 */
	//Darwinsh Saint-Jean
	public void arreter() {
		enCoursDAnimation = false;
	}
	
	/** Méthode qui permet de reinitialiser les élements du jeu à leur état initial
	 */		
	//Darwinsh Saint-Jean
	public void reinitialiser() {
		arreter();
		remiseScoreZero();

		raton.setPosition(posInitRaton);
		raton.setVitesse(vecZero);
		raton.setAccel(vecZero);
		raton.setSommeDesForces(vecZero);
		raton.setY(posY);

		forceAssocie.setValue(forceInit);
		orientationAssocie.setValue(orientationInit);
		conteurAnimation = valeurZero;
		remettreBackgroundAZero();
		remettreBarreDeProgresAZero();
		creerObstacles();
		premiereFoisDessin = true;
		peutCliquer = true;
		afficherLabelCommencer = true;

		repaint();
	}

	/** indique si l'utilisateur peut cliquer ou non (cliquer pour commencer).
	 * @return true s'il peut cliquer, sinon false.
	 */
	//Darwinsh Saint-Jean
	public boolean getPeutCliquer() {
		return peutCliquer;
		
	}

	/** Remet la valeur affichée dans la barre de progression à zero.
	 */
	//Darwinsh Saint-Jean
	public void remettreBarreDeProgresAZero() {
		progressionPrecedente = valeurZero; 
		firePropertyChange("progression", null, valeurZero); 
		repaint();
	}


	/** Réinitialise la position de l'arrière plan à sa valeur initiale.
	 */
	//Darwinsh Saint-Jean
	public void remettreBackgroundAZero() {
		coinGaucheImageXProche = valeurZero;
		coinGaucheImageXLoin = valeurZero;
		coinGaucheImageY = valeurZero;
		coinDroitImageXProche = coinXDroitInit;
		coinDroitImageXLoin = coinXDroitInit;
		coinDroitImageY = coinYDroitInit;
		moitieBackgroundProche = moitieBackgroundProcheInit;
		moitieBackgroundLoin = moitieBackgroundLoinInit;
	}

	/** Dessine la flèche. 
	 * la modification de l'épaisseur affecte juste la flèche. 
	 * @param g2d l'objet Graphics2D utilisé pour le dessin
	 */
	//Darwinsh Saint-Jean
	public void dessinFleche(Graphics2D g2d) {
		g2d.setColor(Color.MAGENTA);
		g2d.setStroke(new BasicStroke(strokeBase));
		orientation.dessiner(g2d);
	}

	/** Associe le slider d'orientation défini dans une autre classe à cette classe afin d'ajuster l'angle d'orientation.
	 * @param slider représente le sliderOrientation provenant de la classe Jouer.
	 */	
	//Darwinsh Saint-Jean
	public void setOrientationAssocie(JSlider slider) {
		this.orientationAssocie = slider;
	}

	/** Associe le slider de force défini dans une autre classe à cette classe.
	 * @param slider2 représente le sliderForce provenant de la classe Jouer.
	 */
	//Darwinsh Saint-Jean
	public void setForceAssocie(JSlider slider2) {
		this.forceAssocie = slider2;
	}	

	/** Associe le bouton suivant défini dans une autre classe à cette classe
	 * @param bouton représente le btnSuivant provenant de la classe Jouer.
	 */
	//Darwinsh Saint-Jean
	public void setSuivantAssocie(JButton bouton) {
		this.suivantAssocie = bouton ;
	}

	/** Associe le bouton terminer défini dans une classe à cette classe.
	 * @param bouton2 représente le btnTermine provenant de la classe Jouer.
	 */
	//Darwinsh Saint-Jean
	public void setTermineAssocie (JButton bouton2) {
		this.termineAssocie = bouton2;
	}


	/** Rend le slider de force visible.
	 */
	//Darwinsh Saint-Jean
	public void rendreSForceVisible() {
		forceAssocie.setEnabled(true);
		forceAssocie.setVisible(true);
	}


	/** Rend le slider d'orientation visible.
	 */
	//Darwinsh Saint-Jean
	public void rendreSOrientationVisible() {
		orientationAssocie.setVisible(true);
		orientationAssocie.setEnabled(true);
	}

	/** Rend le bouton suivant visible.
	 */
	//Darwinsh Saint-Jean
	public void rendreBoutonSuivantVisible() {
		suivantAssocie.setVisible(true);
		suivantAssocie.setEnabled(true);
	}

	/** Rend le bouton Terminer visible.
	 */
	//Darwinsh Saint-Jean
	public void rendreBoutonTermineVisible() {
		termineAssocie.setVisible(true);
		termineAssocie.setEnabled(true);
	}


	/** Fait disparaître le bouton terminer.
	 */
	//Darwinsh Saint-Jean
	public void termineDisparait() {
		termineAssocie.setVisible(false);
		termineAssocie.setEnabled(false);
	}

	/** Fait disparaître le bouton suivant.
	 */
	//Darwinsh Saint-Jean
	public void suivantDisparait() {
		suivantAssocie.setVisible(false);
		suivantAssocie.setEnabled(false);
	}

	/** Fait disparaître le slider de force.
	 */
	//Darwinsh Saint-Jean
	public void sForceDisparait() {
		forceAssocie.setEnabled(false);
		forceAssocie.setVisible(false);
	}


	/** Fait disparaître le slider d'orientation.
	 */
	//Darwinsh Saint-Jean
	public void sOrientationDisparait() {
		orientationAssocie.setVisible(false);
		orientationAssocie.setEnabled(false);
	}


	/** Calcul les nouvelles positions pour tous les objets présents dans la scène. 
	 * 	Met à jour les valeurs de la barre de progression, du score et gère les collisions.
	 * @param deltaT Le temps écoulé en secondes.
	 */
	//Darwinsh Saint-Jean
	private void calculerUneIterationPhysique(double deltaT) throws Exception {
	    tempsTotalEcoule += deltaT;
	    incrementDeplacementX = raton.getIncrementX(deltaT);
	    raton.calculerIteration(deltaT);
	    //collisions
	    testerCollisionsEtModifierVitesses();
	    //deplacement
	    niveau1.deplacerObstacles(incrementDeplacementX * pixelsParMetre);
	    niveau2.deplacerObstacles(incrementDeplacementX * pixelsParMetre);
	    niveau3.deplacerObstacles(incrementDeplacementX * pixelsParMetre);
	    
	    //À modifier pour le sprint 2
	    gestionnaire.calculVitesse(deltaT, raton.getVitesse(), gestionnaire.getAcceleration());
        gestionnaire.calculPosition(deltaT, raton.getPosition(), gestionnaire.getVitesse());
        gestionnaire.calculForceGrav(masseRaton);

        leverEvenement();
        
	    deplacerBackground(incrementDeplacementX * 50 * pixelsParMetre);
	    barreDeProgresEtScore();
	    repaint();
	}


/**Permet d'appliquer la force  pour que le champ se fait attirer
 * 
 * 
 */
//Edson François Gertilus
    public void appliquerForces() {
	if (raton.estAttractionActif()) {
            Champ champ = raton.getChampAttire();
           double[] force = MoteurPhysique.calculForceElectrique( raton.getX(), raton.getY(), raton.getCharge(),champ.getX(), champ.getY(), champ.getCharge());
            raton.ajouterForce(force[0], force[1]);
        }
    }
		
	/**
	 * Initialise les niveaux du jeu.
	 */
	//Stanislav Kouznetsov
	private void creerNiveaux() {
		niveau1 = new Niveau (longeurNiveau, hauteurNiveau);
		niveau2 = new Niveau (longeurNiveau, hauteurNiveau);
		niveau3 = new Niveau (longeurNiveau, hauteurNiveau);

	}

	/**
	 * Ajoute les obstacles au niveau sélectionné.
	 */
	//Stanislav Kouznetsov
	public void creerObstacles() {
		if (niveauSelectionne == 1) {
		
			obstacleNiveau1();
		} else if (niveauSelectionne == 2) {
		
			obstacleNiveau2();
		} else if (niveauSelectionne == 3) {
			
			obstacleNiveau3();
		}
	}
	public void tailleNiveau() {
		switch (niveauSelectionne) {
        case 1:
            longeurNiveau = 5000;
            break;
        case 2:
            longeurNiveau = 10000;
            break;
        case 3:
            longeurNiveau = 15000;
            break;
    }
}

	/**
	 * Ajoute les obstacles spécifiques au niveau 1.
	 */
	//Stanislav Kouznetsov
	public void obstacleNiveau1() {

		niveau1.ajouterVoiture(new Voiture(new Vecteur2D(35,0)));

		//test
		niveau1.ajouterRecharge(new Recharge(new Vecteur2D(5,2)));
		niveau1.ajouterVoiture(new Voiture(new Vecteur2D(50,0)));
		niveau1.ajouterRoche(new Roche(new Vecteur2D(70,0)));
		niveau1.ajouterBoostVertical(new BoostVertical(new Vecteur2D(85,3)));
		niveau1.ajouterSapin(new Sapin(new Vecteur2D(100,0)));
		niveau1.ajouterBoostVertical(new BoostVertical(new Vecteur2D(120,2)));
		niveau1.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(125,3)));
		niveau1.ajouterBatiment(new Batiment(new Vecteur2D(130,0)));
		niveau1.ajouterChamp(new Champ(new Vecteur2D(160,4)));
		niveau1.ajouterRoche(new Roche(new Vecteur2D(170,0)));
		niveau1.ajouterRecharge(new Recharge(new Vecteur2D(190,3)));
		niveau1.ajouterBoostVertical(new BoostVertical(new Vecteur2D(200,3)));
		niveau1.ajouterSapin(new Sapin(new Vecteur2D(210,0)));
		niveau1.ajouterVoiture(new Voiture(new Vecteur2D(220,0)));
		niveau1.ajouterRoche(new Roche(new Vecteur2D(230,0)));
		niveau1.ajouterBoostVertical(new BoostVertical(new Vecteur2D(250,2)));
		niveau1.ajouterBatiment(new Batiment(new Vecteur2D(260,0)));
		niveau1.ajouterVoiture(new Voiture(new Vecteur2D(290,0)));
		niveau1.ajouterVoiture(new Voiture(new Vecteur2D(320,0)));
		niveau1.ajouterRoche(new Roche(new Vecteur2D(350,0)));
		niveau1.ajouterChamp(new Champ(new Vecteur2D(380,3)));
		niveau1.ajouterRecharge(new Recharge(new Vecteur2D(400,2)));
		niveau1.ajouterSapin(new Sapin(new Vecteur2D(420,0)));
		niveau1.ajouterSapin(new Sapin(new Vecteur2D(440,0)));
		niveau1.ajouterBatiment(new Batiment(new Vecteur2D(460,0)));
		niveau1.ajouterRoche(new Roche(new Vecteur2D(480,0)));
		niveau1.ajouterChamp(new Champ(new Vecteur2D(15,3)));
		
		niveau1.ajouterBatiment(new Batiment(new Vecteur2D(490,0)));
		niveau1.ajouterBatiment(new Batiment(new Vecteur2D(500,0)));
		niveau1.ajouterBatiment(new Batiment(new Vecteur2D(510,0)));
		niveau1.ajouterBatiment(new Batiment(new Vecteur2D(520,0)));
		niveau1.ajouterBatiment(new Batiment(new Vecteur2D(530,0)));
		
		
		

	}

	/**
	 * Ajoute les obstacles spécifiques au niveau 2.
	 */
	//Stanislav Kouznetsov
	public void obstacleNiveau2() {

		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(10, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(15, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(22, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(33, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(40, 3)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(55, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(60, 2)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(73, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(90, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(102, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(110, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(120, 3)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(124, 0)));
		niveau1.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(128,3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(138, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(150, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(155, 2)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(160, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(164, 4)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(168, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(176, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(182, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(185, 2)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(194, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(198, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(203, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(208, 3)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(214, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(221, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(234, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(238, 2)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(245, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(249, 2)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(258, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(266, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(278, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(281, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(287, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(292, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(299, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(302, 4)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(310, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(315, 2)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(321, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(333, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(340, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(344, 3)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(351, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(356, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(362, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(366, 3)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(371, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(383, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(387, 2)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(396, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(400, 2)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(408, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(414, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(418, 3)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(425, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(429, 3)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(437, 0)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(442, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(446, 2)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(452, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(458, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(463, 3)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(470, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(474, 2)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(481, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(487, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(491, 3)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(497, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(502, 2)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(508, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(513, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(519, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(525, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(529, 2)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(535, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(541, 2)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(547, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(551, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(558, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(564, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(571, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(576, 3)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(580, 3)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(586, 0)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(592, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(597, 2)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(603, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(607, 3)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(613, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(618, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(623, 2)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(630, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(635, 3)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(641, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(646, 2)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(652, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(657, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(661, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(667, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(673, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(678, 3)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(684, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(689, 2)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(695, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(700, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(706, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(712, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(716, 3)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(722, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(727, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(732, 2)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(738, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(743, 2)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(749, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(755, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(760, 3)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(766, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(770, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(777, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(783, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(787, 4)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(793, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(798, 2)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(804, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(809, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(815, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(821, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(825, 3)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(831, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(836, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(841, 2)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(847, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(852, 2)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(858, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(864, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(869, 3)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(875, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(879, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(886, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(892, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(896, 2)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(902, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(907, 2)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(913, 0)));
		niveau2.ajouterChamp(new Champ(new Vecteur2D(918, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(924, 0)));
		niveau2.ajouterSapin(new Sapin(new Vecteur2D(930, 0)));
		niveau2.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(934, 3)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(940, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(945, 0)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(950, 3)));
		niveau2.ajouterVoiture(new Voiture(new Vecteur2D(956, 0)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(960, 2)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(955, 3)));
		niveau2.ajouterBoostVertical(new BoostVertical(new Vecteur2D(960, 2)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(965, 2)));
		niveau2.ajouterRecharge(new Recharge(new Vecteur2D(965, 3)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(975, 0)));;
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(975, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(980, 0)));
		niveau2.ajouterBatiment(new Batiment(new Vecteur2D(985, 0)));
		niveau2.ajouterRoche(new Roche(new Vecteur2D(990, 0)));

		
		
	}
	/**
	 * Ajoute les obstacles spécifiques au niveau 3.
	 */
	//Stanislav Kouznetsov
	public void obstacleNiveau3() {
		
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(10, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(17, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(22, 3)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(30, 0)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(37, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(42, 3)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(50, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(55, 2)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(61, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(69, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(75, 3)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(81, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(88, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(94, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(100, 3)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(108, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(115, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(120, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(126, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(132, 3)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(138, 4)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(145, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(152, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(160, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(165, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(172, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(177, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(184, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(190, 2)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(197, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(204, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(210, 3)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(216, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(223, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(228, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(235, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(242, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(250, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(256, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(263, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(269, 3)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(275, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(282, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(287, 3)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(293, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(300, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(306, 4)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(313, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(318, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(325, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(331, 3)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(337, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(344, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(351, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(357, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(364, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(369, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(376, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(382, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(388, 3)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(395, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(401, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(408, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(414, 4)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(421, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(427, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(432, 2)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(438, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(445, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(451, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(458, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(464, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(470, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(476, 3)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(481, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(487, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(494, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(500, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(506, 0)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(513, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(518, 4)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(524, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(529, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(535, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(541, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(548, 0)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(555, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(560, 3)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(566, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(573, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(578, 2)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(584, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(589, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(595, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(601, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(606, 3)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(612, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(617, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(624, 0)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(630, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(635, 4)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(641, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(646, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(652, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(658, 3)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(663, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(670, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(676, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(681, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(688, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(693, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(699, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(705, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(710, 3)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(717, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(723, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(730, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(736, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(743, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(749, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(754, 2)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(760, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(767, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(773, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(780, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(786, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(792, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(798, 4)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(803, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(809, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(815, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(821, 3)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(828, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(834, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(841, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(847, 2)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(854, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(860, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(865, 2)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(871, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(878, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(884, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(891, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(897, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(903, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(909, 3)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(914, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(920, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(926, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(932, 3)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(939, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(945, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(952, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(958, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(964, 2)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(971, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(977, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(983, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(990, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(997, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(1003, 3)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1010, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(1017, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(1023, 4)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(1028, 2)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(1034, 0)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1041, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(1047, 3)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(1054, 3)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1060, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(1067, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(1073, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(1079, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1086, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(1092, 2)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(1098, 3)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1105, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(1111, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(1118, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(1124, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(1130, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1137, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(1143, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1149, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(1156, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(1163, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(1169, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(1175, 3)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(1181, 4)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1188, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(1194, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1201, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(1207, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(1213, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(1219, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(1225, 3)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(1231, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1238, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(1244, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1250, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(1257, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(1263, 0)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(1270, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(1276, 3)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1282, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(1288, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1295, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(1301, 3)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(1308, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(1315, 3)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(1321, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(1327, 4)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1333, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(1339, 2)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1345, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(1350, 3)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1353, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1358, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1364, 0)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(1370, 3)));
		niveau3.ajouterRoche(new Roche(new Vecteur2D(1376, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(1382, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1388, 0)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1393, 0)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1398, 0)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(1404, 0)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(1410, 3)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1416, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1421, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1426, 0)));
		niveau3.ajouterRecharge(new Recharge(new Vecteur2D(1432, 2)));
		niveau3.ajouterVoiture(new Voiture(new Vecteur2D(1438, 0)));
		niveau3.ajouterChamp(new Champ(new Vecteur2D(1444, 3)));
		niveau3.ajouterBoostHorizontal(new BoostHorizontal(new Vecteur2D(1450, 3)));
		niveau3.ajouterBoostVertical(new BoostVertical(new Vecteur2D(1455, 2)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1460, 0)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1465, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1470, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1475, 0)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1480, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1485, 0)));
		niveau3.ajouterSapin(new Sapin(new Vecteur2D(1490, 0)));
		niveau3.ajouterBatiment(new Batiment(new Vecteur2D(1495, 0)));



	}

	/**
	 * Met à jour la barre de progression, le score du joueur, le jeu s'arrête quand le joueur atteint 100% du niveau 
	 * et lorsqu'il est à 0%.
	 */
	//Stanislav Kouznetsov
	public void barreDeProgresEtScore() {

		
		  positionX += raton.getIncrementX(deltaT); 
		  int progression = (int) ((((int) (((positionX*pixelsParMetre) / (double) longeurNiveau) * divProgres))));
		  progressionActuelle = progression;
		
		
		    

		int nouveauxPoints = progression / 1;

		if (progression != progressionPrecedente) {
			firePropertyChange("progression", progressionPrecedente, progression);
			progressionPrecedente = progression;
		}

		if(nouveauxPoints > scorePrecedent) {
			score = nouveauxPoints;
			firePropertyChange("score", scorePrecedent, score);
			scorePrecedent = score;
		}
		if (progression >= nivComplet) {
		enCoursDAnimation = false;
			System.out.println("Niveau terminé !");
		}
		
		if(progression < 0) {
			enCoursDAnimation = false;
		}	
		

	}



	/**
	 * Réinitialise le score à zéro.
	 */
	//Stanislav Kouznetsov
	public void remiseScoreZero() {

		score = 0; 
		firePropertyChange("score", null, score);

	}

	

	/**
	 * Dessine une échelle graduée représentant la progression du joueur sur le niveau.
	 * 
	 * @param g2d Objet Graphics2D utilisé pour dessiner l'échelle.
	 */
	//Stanislav Kouznetsov
	//Stanislav Kouznetsov
		public void dessinerEchelle(Graphics2D g2d) {
			
			g2d.setColor(Color.YELLOW);
			g2d.setStroke(new BasicStroke(2));
			int yEchelle = getHeight() - 50;
			g2d.drawLine(0, yEchelle, getWidth(), yEchelle);
			
			int maxMetres;
		    if (niveauSelectionne == 1) {
		        maxMetres = 500;
		    } else if (niveauSelectionne == 2) {
		        maxMetres = 1000;
		    } else { 
		        maxMetres = 1500;
		    }

		    int progression = (int) (((double) progressionActuelle / divProgres) * maxMetres)*echelleGrad;
		   
		    int debutEchelle = Math.max(0, progression - 5);
		    int positionMetres = progression;
			
			int nombreGraduations = 10;
			double pixelsParMetreLocal = getWidth() / (double) nombreGraduations;


			for (int i = 0; i <= nombreGraduations; i++) {
				int xGraduation = (int) (i * pixelsParMetreLocal);
				int valeurMetres = debutEchelle + i;
				g2d.drawLine(xGraduation, yEchelle - 5, xGraduation, yEchelle + 5);
				g2d.drawString(valeurMetres + " m", xGraduation - 10, yEchelle - 10);
			}
			
			if (positionMetres != progressionPrecedente) {
				firePropertyChange("echelle", progressionPrecedente, positionMetres);
				progressionPrecedente = positionMetres;
			}
		}


	/**
	 * Déclenche les événements de mise à jour des propriétés physiques.
	 */
	 //Stanislav Kouznetsov
		public void leverEvenement() {
		MoteurPhysique moteurPhysique = new MoteurPhysique();
		GestionnaireEvenementsPhysique gestionnaire = new GestionnaireEvenementsPhysique(moteurPhysique);
		    pcs.firePropertyChange("position", null, gestionnaire.getPosition());
		    pcs.firePropertyChange("vitesse", null, gestionnaire.getVitesse());
		    pcs.firePropertyChange("acceleration", null, gestionnaire.getAcceleration());
		    pcs.firePropertyChange("forceGrav", null, gestionnaire.getForceGrav());
		}

	

	/**
	 * permet de tester les collisions entre chaque composant du jeu et le raton et modifier les vitesses si il y a lieu
	 * @throws Exception 
	 */
	//Justin Gauthier
	private void testerCollisionsEtModifierVitesses() throws Exception {
		//collision avec obstacles
		niveau1.testerCollisionsBatiment(raton);
		niveau1.testerCollisionsRoche(raton);
		niveau1.testerCollisionsSapin(raton);

		//collision avec ameliorations
		niveau1.testerCollisionsBoostVertical(raton);
		niveau1.testerCollisionsChamp(raton);
		niveau1.testerCollisionsBoostHorizontal(raton);
		niveau1.testerCollisionsRecharge(raton);

		//collision avec sol
		raton.gererCollisionSol(sol.getY());

	}

	/**
	 * Permet de créer la force de lancement selon le choix d'angle et de force de l'utilisateur au debut du jeu
	 * @param angle l'angle choisi par l'utilisateur
	 * @param force la force choisie par l'utilisateur
	 * @return
	 */
	//Justin Gauthier
	private Vecteur2D creerForceLancement(double angle, double force) {
		double forceY = force*Math.sin(Math.toRadians(angle));
		double forceX = force*Math.cos(Math.toRadians(angle));
		Vecteur2D fLancement = new Vecteur2D(0.5*forceX, -5*forceY);
		return fLancement;
	}

	/**
	 * Permet de deplacer le background selon un increment en x 
	 * @param incrementX l'incrément de déplacement du background en x
	 */
	//Justin Gauthier
	private void deplacerBackground(double incrementX) {
		coinGaucheImageXProche += incrementX;
		coinDroitImageXProche += incrementX;
		coinGaucheImageXLoin += incrementX/2.5;
		coinDroitImageXLoin += incrementX/2.5;
		
		if(raton.getVitesse().getX() >= 0) {
			if(coinGaucheImageXProche >= moitieBackgroundProche) {

				coinGaucheImageXProche = coinGaucheDessinProche;
				coinDroitImageXProche = 1224;
			}

			if(coinGaucheImageXLoin >= moitieBackgroundLoin) {

				coinGaucheImageXLoin = coinGaucheDessinLoin;
				coinDroitImageXLoin = 1224;
			}
		}
		
		if (raton.getVitesse().getX() < 0) {
			if(coinGaucheImageXProche <= 0) {
				
				coinGaucheImageXProche = coinGaucheDessinProche + moitieBackgroundProche;
				coinDroitImageXProche = 1224*2;
			}
			
			if(coinGaucheImageXLoin <= 0) {
				
				coinGaucheImageXLoin = coinGaucheDessinLoin + moitieBackgroundLoin;
				coinDroitImageXLoin = 1224*2;
		
			}
		}

		repaint();
	}

	/**
	 * Permet de transmettre la valeur du slider de l'orientation dans la classe Jouer à la force de lancement dans cette classe
	 * @param orientationForce la valeur du slider de l'orientation dans la classe Jouer
	 */
	//Justin Gauthier
	public void setOrientation(double orientationForce){
		this.orientationForceLancement = orientationForce;
	}

	/**
	 * Permet de transmettre la valeur du slider de la force dans la classe Jouer à la force de lancement dans cette classe
	 * @param forceForce la valeur du slider de la force dans la classe Jouer
	 */
	//Justin Gauthier
	public void setForce(double forceForce) {
		this.forceForceLancement = forceForce;
	}


	

	/**
	 * Permet de gérer la barre de newtons selon les évenements du clavier
	 * @param e le parametre du clavier
	 */
	//Justin Gauthier
	private void gererClavierPressed(KeyEvent e) {
		//on peut seulement cliquer si le jeu est en cours
		if(enCoursDAnimation) {
			if (e.getKeyCode() ==  KeyEvent.VK_SPACE) {
				if(barreNewtons.getConsommationRestante()>0) {
					//si la vitese du raton est négative, on le ramene sur le droit chemin
					if(raton.getVitesse().getX() < 0) {
						raton.setVitesse(new Vecteur2D(-raton.getVitesse().getX(), -5));
						//si elle est positive, on lui donne simplement un boost horizontal
					}else {
						raton.setVitesse(new Vecteur2D(raton.getVitesse().getX(), -5));
					}
					//on diminue la barre de newtons
					barreNewtons.consommerBarre(0.1);
				}
			}
		}
	}
	
	/**
	 * Dessiner le background selon l'incrément de déplacement
	 * @param g2d le contexte graphique
	 */
	//Justin Gauthier
	private void dessinerBackground(Graphics g2d) {
		//ciel, nuages et montagnes
		g2d.drawImage(backgroundLoin ,coinGaucheDessinLoin , 0, coinDroitDessinLoin, 620, coinGaucheImageXLoin, coinGaucheImageY, coinDroitImageXLoin, coinDroitImageY, null);
		//sol et arbres
		g2d.drawImage(backgroundProche,coinGaucheDessinProche , 0, coinDroitDessinProche, 620, coinGaucheImageXProche, coinGaucheImageY-300, coinDroitImageXProche, coinDroitImageY-300, null);
		
	}
	
	/**
	 * Lire les images une seule fois afin d'améliorer le roulement de l'application
	 */
	//Justin Gauthier
	private void creerImages() {
		backgroundLoin = OutilsImage.lireImage("background loin.png");
		backgroundProche = OutilsImage.lireImage("background proche.png");
	}

}
