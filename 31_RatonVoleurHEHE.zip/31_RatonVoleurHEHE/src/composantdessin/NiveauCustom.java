package composantdessin;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;

import javax.swing.JPanel;

import geometrieDessin.Vecteur2D;
import obstacles.Roche;
import outils.OutilsImage;

public class NiveauCustom extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private JeuPrincipal jeu;
	
    
    /** Largeur du composant en mètres. */
	private double largeurDuComposantEnMetres = 20;
	
	/**Haueur du composant en mètres. **/
	private double hauteurDuComposantEnMetres;
    
    private double pixelsParMetre;
    
    /** Coordonnées en x de l'image d'arrière-plan loin, coin gauche*/
    private int coinGaucheImageXLoin = 0;
    /** Coordonnées en x de l'image d'arrière-plan proche, coin gauche*/
    private int coinGaucheImageXProche = 0;
    /** Coordonnées en y de l'image d'arrière-plan, coin gauche */
    private int coinGaucheImageY = 0;
    /** Coordonnées en x de l'image d'arrière-plan loin, coin droit*/
    private int coinDroitImageXLoin = 1224;
    /** Coordonnées en x de l'image d'arrière-plan proche, coin droit*/
    private int coinDroitImageXProche = 1224;
    /** Coordonnées en y de l'image d'arrière-plan, coin droit*/
    private int coinDroitImageY = 688;
    
    private double facteurZoom = 1;
    
    private Image backgroundLoin;
    
	private Image backgroundProche;
	
	private ArrayList<Roche> listeDesRoches=  new ArrayList<>();
	ArrayList<Roche> listeRocheTemporaire;
	private boolean deplacerRoche;

	/**
	 * Creer la fenetre
	 */
	public NiveauCustom() {
		 
		
		setBackground(Color.white);
		addComponentListener(new ComponentAdapter() {
	        @Override
	        public void componentResized(ComponentEvent e) {
	            pixelsParMetre = getWidth() / largeurDuComposantEnMetres;
	            hauteurDuComposantEnMetres = getHeight() / pixelsParMetre;
	           
	        }
	    });

		lireImages();
		gestionnaireDeplacementRoche();
	}
	
	
	  
	 
	//Darwinsh Saint-Jean
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g; 
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON );                     
		
		
		
			
			dessinerBackground(g2d);
			dessinRoches(g2d);
	}
	
	
	
	
	
	//Justin Gauthier
	private void dessinerBackground(Graphics2D g2d) {

	    // Nuages + Montagnes
 	    g2d.drawImage(backgroundLoin, 0, 0, 1560, 485, coinGaucheImageXLoin, coinGaucheImageY, coinDroitImageXLoin, coinDroitImageY, null);

	    // Sol + Arbres
	    g2d.drawImage(backgroundProche, 0, 0, 1560, 485, coinGaucheImageXProche, coinGaucheImageY - 300, coinDroitImageXProche, coinDroitImageY - 300, null);
	}
	
	
	//Darwinsh Saint-Jean
	public void gestionnaireDeplacementRoche(){
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				 System.out.println("est :" + pixelsParMetre);
                for (Roche roche : listeDesRoches) {
                    if (roche.contient(e.getX(), e.getY())) {
                    	listeRocheTemporaire =  new ArrayList<Roche>();
                    	for (Roche r :  listeDesRoches) {
                    		listeRocheTemporaire.add(r);
                    	}
                        roche.setSelectionne(true);
                        deplacerRoche = true;
                        System.out.println("clic dans roche");
                        
                        repaint();
                        break;
                    }
                }
            }
			
			@Override
			 public void mouseReleased(MouseEvent e) {
	            for (Roche roche : listeDesRoches) {
	                if (roche.getSelectionne()) {
	                    roche.setSelectionne(false);
	                    deplacerRoche = false;
	                    repaint();
	                    break;
	                }
	            }
	        }
		});
		
		addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                
                for (Roche roche : listeDesRoches) {
                    if (roche.getSelectionne()) {
                        
                    	double PosX = e.getX() / pixelsParMetre - roche.getLongueurRoche()/2;
                        double posY = e.getY() / pixelsParMetre - roche.getHauteurRoche()/4;
                        roche.setX(PosX);
                        roche.setY(posY);

                        System.out.println("Pixels per meter: " + pixelsParMetre);
                        repaint();
                        break; 
                    }
                }
            }
        });
	}
	
	public void lireImages() {
		backgroundLoin =OutilsImage.lireImage("background loin.png");
		backgroundProche = OutilsImage.lireImage("background proche.png");
	}
	
	
	public void dessinRoches(Graphics2D g2d) {
		for (Roche roche : listeDesRoches) {
			roche.setPixelsParMetre(pixelsParMetre);
			roche.dessiner(g2d);
			
		}
		//repaint();
	}
	
	public void ajouterRoche() {
	    Vecteur2D position = new Vecteur2D(10,1 );
	    Roche roche = new Roche(position);
	    listeDesRoches.add(roche);
	    System.out.println("Roche ajoutée à la position : " + position + " la hauteur du composant est: " + hauteurDuComposantEnMetres);
	    repaint();
	}
	

	
	
}
